# Compiler diagnostics and AI observations

The Coach now shows an orange local-javac result section before the purple AI review section. Compilation success means only that this single-file compilation reported no errors; logic and runtime behavior are explicitly unverified. Compiler history uses “last reported” and “no longer reported,” not mastery or resolved-logic claims.

AI observations show source, verification status, code evidence, a possible issue, reasoning, an unexecuted candidate counterexample, and verification steps. New responses must supply the additional fields. Old saved observations still decode and display explicit fallbacks for missing fields.

Review actions are “I tested it and reproduced it,” “This does not apply,” and a reset to pending. Reproduction is a user report, never system verification. Old Confirm decisions remain saved but count as pending because the old button did not ask whether a test was run; old Dismiss decisions map to not applicable.

Habits and Progress display compiler statistics separately from AI observations. Concept summaries separate pending, user-reproduced, and not-applicable counts across distinct source snapshots. Only user-reproduced snapshots contribute to repeated-user-report labels. Pending observations remain available for exploratory practice, with their verification status included in AI requests. Example history remains separate.

DeepSeek, OpenAI, Databricks, their existing setup controls, model identifiers, Keychain services, and network endpoints are unchanged. No real API request or credential inspection was performed.

Validation: complete native app compiled for Apple Silicon, ad-hoc signing verified; 34 XCTest cases executed (30 passed, 4 JDK-dependent cases skipped, zero failures). Additional native model checks verified history round trips, legacy decisions, user review persistence, separated counts, practice eligibility and demo isolation. Synthetic Coach, Habits and Progress views were rendered for layout inspection. These checks do not establish live model accuracy or full cross-editor compatibility.
