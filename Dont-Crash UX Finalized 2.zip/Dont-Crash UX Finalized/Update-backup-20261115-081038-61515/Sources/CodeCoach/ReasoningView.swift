import SwiftUI
#if SWIFT_PACKAGE
import CodeCoachCore
#endif
struct PracticeSession:Codable,Identifiable {
    var id=UUID()
    var day:String
    var exercises:[Quiz]
    var answers:[Int]
}
@MainActor final class ReasoningModel:ObservableObject {
    @Published var code=""
    @Published var language="java"
    @Published var consent=false { didSet { if !consent { requestID=UUID(); task?.cancel(); task=nil; busy=false } } }
    @Published var observations:[ReasoningObservation]=[]
    @Published var archive:[PracticeSession]=[]
    @Published var showDemo=false
    @Published var exercises:[Quiz]=[]
    @Published var answers:[Int]=[]
    @Published var day=""
    @Published var busy=false
    @Published var message="Source is sent only when you explicitly request analysis."
    private var requestID=UUID()
    private var task:Task<Void,Never>?
    private let url:URL
    struct History:Codable { var observations:[ReasoningObservation]; var exercises:[Quiz]; var answers:[Int]; var day:String; var archive:[PracticeSession]? }
    init(storageURL:URL? = nil) {
        url=storageURL ?? FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0].appendingPathComponent("CodeCoach/reasoning.json")
        if let data=try? Data(contentsOf:url), let h=try? JSONDecoder().decode(History.self,from:data) { observations=h.observations; exercises=h.exercises; answers=h.answers; day=h.day;archive=h.archive ?? []; if answers.count != exercises.count { answers=Array(repeating:-1,count:exercises.count) } }
    }
    func save() {
        do { try FileManager.default.createDirectory(at:url.deletingLastPathComponent(),withIntermediateDirectories:true);try JSONEncoder().encode(History(observations:observations,exercises:exercises,answers:answers,day:day,archive:archive)).write(to:url,options:.atomic) } catch { message="Could not save learning history: "+error.localizedDescription }
    }
    var visibleObservations:[ReasoningObservation] { observations.filter { ($0.isDemo ?? false) == showDemo } }
    var conceptSummaries:[ConceptReviewSummary] { ConceptReviewSummary.summarize(visibleObservations) }
    var personalObservations:[ReasoningObservation] { observations.filter{$0.isDemo != true} }
    func review(_ id:UUID,as status:ObservationVerification) {
        guard let i=observations.firstIndex(where:{$0.id == id}) else { return }
        observations[i].decision=status.rawValue;save()
    }
    func loadExamples() {
        guard !observations.contains(where:{$0.isDemo == true}) else { showDemo=true;return }
        for (index,lang) in ["java","python","javascript"].enumerated() {
            let json="{\"language\":\""+lang+"\",\"concept\":\"Boundary conditions\",\"possibleHabit\":\"Unchecked initialization assumptions\",\"evidence\":\"Example history: a maximum starts at zero despite negative inputs.\",\"confidence\":\"medium\",\"suggestedPractice\":\"Try all-negative and empty inputs.\"}"
            if let analysis=try? JSONDecoder().decode(ConceptAnalysis.self,from:Data(json.utf8)) {
                observations.append(ReasoningObservation(timestamp:Date().addingTimeInterval(Double(-index)*86400),analysis:analysis,sourceEvent:"example-"+String(index),isDemo:true))
            }
        }
        showDemo=true;save()
    }
    func cancelRequest() { task?.cancel();task=nil;consent=false;message="AI requests stopped. Already-sent data cannot be recalled." }
    func clearLearning() {
        cancelRequest(); observations=[];archive=[];exercises=[];answers=[];day="";showDemo=false;save()
        message="Reasoning history and practice cleared. Your Keychain credential was kept."
    }
    func analyze() {
        guard consent,!busy,!code.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty else { return }
        let source=code, lang=language
        let request=UUID();requestID=request
        busy=true
        task=Task {
            defer { if requestID == request { busy=false } }
            do {
                let analysis=try await DeepSeekClient().analyze(code:source,language:lang)
                guard !Task.isCancelled,consent,requestID == request else { return }
                observations.append(ReasoningObservation(analysis:analysis,sourceEvent:Diagnostic.digest(lang+"|"+source),isDemo:false));save()
                message="Interpretation saved. This is a hypothesis, not a verified runtime result."
            } catch { if !Task.isCancelled,requestID == request { message=error.localizedDescription } }
        }
    }
    func testConnection() {
        guard consent,!busy else { return }
        let request=UUID();requestID=request
        busy=true
        task=Task {
            defer { if requestID == request { busy=false } }
            do {
                let data=try await DeepSeekClient().request(instructions:"Return JSON {\"ready\":true}.",input:"Connection test only. No student code or history.")
                guard !Task.isCancelled,consent,requestID == request else { return }
                guard let value=try JSONSerialization.jsonObject(with:data) as? [String:Bool],value["ready"] == true else { throw CoachError.message("Connection responded but the probe was invalid.") }
                message="AI is connected and ready."
            } catch { if !Task.isCancelled,requestID == request { message=error.localizedDescription } }
        }
    }
    struct PracticeObservation:Encodable { let analysis:ConceptAnalysis; let verification:String }
    func practice() {
        guard consent,!busy,!observations.isEmpty else { return }
        let formatter=DateFormatter();formatter.dateFormat="yyyy-MM-dd";formatter.calendar=Calendar.current
        let today=formatter.string(from:Date())
        guard day != today else { message="Today's practice is already saved.";return }
        let concepts=personalObservations.filter{$0.verification != .notApplicable}.suffix(12).map { PracticeObservation(analysis:$0.analysis,verification:$0.verification.rawValue) }
        guard !concepts.isEmpty else { message="Analyze your own code first. Example history is excluded from personal practice.";return }
        let request=UUID();requestID=request
        busy=true
        task=Task {
            defer { if requestID == request { busy=false } }
            do {
                struct PracticeContext:Encodable { let concepts:[PracticeObservation]; let previousQuestions:[Quiz]; let previousAnswers:[Int]; let olderSessions:[PracticeSession] }
                let input=String(decoding:try JSONEncoder().encode(PracticeContext(concepts:Array(concepts),previousQuestions:exercises,previousAnswers:answers,olderSessions:Array(archive.suffix(7)))),as:UTF8.self)
                let data=try await DeepSeekClient().request(instructions:"Create exactly three English programming reasoning exercises based on these conceptual observations: identify an assumption, choose an independently constructed algorithm, transfer the concept to a different problem. Return JSON {exercises:[{question:string,choices:[four distinct strings],answer:zero-based integer,explanation:string}]}. Explain reasoning and a useful counterexample. Verification is user-reported only: Unreviewed is unverified, UserReproduced means the user reports a test reproduced the concern. Neither establishes mastery or a recurring weakness. Use pending observations only for exploratory practice. Never claim any code or test was executed by this app.",input:input)
                struct Response:Decodable { let exercises:[Quiz] }
                let result=try JSONDecoder().decode(Response.self,from:data).exercises
                guard result.count == 3 else { throw CoachError.message("Expected three practice questions. Retry.") }
                let valid=try result.map{try $0.validated()}
                guard !Task.isCancelled,consent,requestID == request else { return }
                if !day.isEmpty { archive.append(PracticeSession(day:day,exercises:exercises,answers:answers)) }
                exercises=valid;answers=Array(repeating:-1,count:3);day=today;save();message="Today's practice is ready."
            } catch { if !Task.isCancelled,requestID == request { message=error.localizedDescription } }
        }
    }
}
struct ReasoningView:View {
    @ObservedObject var model:ReasoningModel
    let section:Int
    @State private var selections:[Int:Int]=[:]
    @State private var hints:Set<Int>=[]
    var body:some View {
        VStack(alignment:.leading,spacing:18) {
            if section == 0 {
                Label("AI code review · DeepSeek",systemImage:"sparkles").font(.headline).foregroundStyle(Color.purple)
                Text("Possible logic issues · code and candidate tests are not executed by this app.").font(.callout)
            }
            Toggle("Enable AI coaching",isOn:$model.consent)
            Text("AI sends your reviewed code or learning history when you ask. Usage may cost money.").font(.system(size:14))
            if section == 4 {
                Text("AI connection").font(.system(size:19,weight:.semibold))
                Button("Test AI") { model.testConnection() }.buttonStyle(.borderedProminent).disabled(!model.consent || model.busy)
                Text("Turning off AI consent stops new requests and cancels pending work. Already-sent data cannot be recalled.")
            } else if section == 0 {
                Button("Test AI") { model.testConnection() }.disabled(!model.consent || model.busy)
                Divider()
                Picker("Language",selection:$model.language) { ForEach(["java","python","javascript","c","cpp","r"],id:\.self) { Text($0).tag($0) } }
                Text("Code review").font(.system(size:19,weight:.semibold))
                Text("Review your code, then analyze.").font(.callout)
                if model.code.isEmpty { Text("Choose a file or paste code here.").foregroundStyle(.secondary) }
                TextEditor(text:$model.code).font(.system(size:14,design:.monospaced)).frame(height:180).padding(8).overlay(RoundedRectangle(cornerRadius:8).stroke(Color.blue.opacity(0.25)))
                Divider()
                Button("Analyze my reasoning") { model.analyze() }.buttonStyle(.borderedProminent).controlSize(.large).disabled(!model.consent || model.busy || model.code.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty)
                if let latest=model.personalObservations.last {
                    AIObservationCard(observation:latest) { status in model.review(latest.id,as:status) }
                }
            } else if section == 1 {
                Text("AI concept observations").font(.system(size:19,weight:.semibold))
                Text("AI suggestions are unverified until you test them. User reports are separate from compiler diagnostics; neither measures mastery.").font(.system(size:14))
                Toggle("View labeled example history",isOn:$model.showDemo)
                Button("Load example history") { model.loadExamples() }.buttonStyle(.bordered)
                conceptSummary
                ForEach(model.visibleObservations) { observation in
                    AIObservationCard(observation:observation) { status in model.review(observation.id,as:status) }
                }
            } else if section == 3 {
                Text("Your learning trail").font(.system(size:19,weight:.semibold))
                Text("Saved activity and user reports, not a measure of mastery.")
                HStack {
                    Label("\(model.observations.filter{$0.isDemo != true}.count) observations",systemImage:"lightbulb")
                    Label("\(model.answers.filter{$0 >= 0}.count) answers in current practice",systemImage:"checkmark.circle")
                }.padding().background(.blue.opacity(0.05),in:RoundedRectangle(cornerRadius:12))
                Text("Practice date: "+(model.day.isEmpty ? "Not started" : model.day))
                Text("AI observations · not run or verified: \(model.personalObservations.filter{$0.verification == .pending}.count)")
                Text("AI observations · user reports reproduced: \(model.personalObservations.filter{$0.verification == .userReproduced}.count)")
                Text("AI observations · user reports not applicable: \(model.personalObservations.filter{$0.verification == .notApplicable}.count)")
                Text("User reports are not system-verified test results.").font(.callout)
                personalConceptSummary
                Text("Example history is excluded.").font(.callout)
                ForEach(model.archive.reversed()) { session in
                    Text(session.day+" · "+String(session.answers.filter{$0 >= 0}.count)+"/"+String(session.exercises.count)+" completed").font(.system(size:17,weight:.semibold)).foregroundStyle(Color.indigo)
                }
            } else {
                Divider()
                Text("Your daily practice").font(.system(size:19,weight:.semibold))
                Text("Three reasoning questions each day. Pending AI observations may be used for exploratory practice; they are not confirmed weaknesses.").font(.callout)
                Button("Create today's three exercises") { model.practice() }.disabled(!model.consent || model.busy)
                Text("Completed: \(model.answers.filter{$0 >= 0}.count)/\(model.exercises.count)")
                ForEach(model.exercises.indices,id:\.self) { i in
                    let q=model.exercises[i]
                    VStack(alignment:.leading,spacing:14) {
                        Text("Exercise \(i+1)").font(.system(size:19,weight:.semibold))
                        Button(hints.contains(i) ? "Hide hint" : "Give me a hint") { if hints.contains(i) { hints.remove(i) } else { hints.insert(i) } }.buttonStyle(.bordered)
                        if hints.contains(i) { Text("Reasoning prompt: trace a small example by hand, then try an empty, boundary, or negative input. Which assumption does each option make?").padding().background(.blue.opacity(0.06),in:RoundedRectangle(cornerRadius:12)) }
                        Text(q.question).font(.system(size:17,weight:.semibold)).foregroundStyle(Color.indigo)
                        ForEach(q.choices.indices,id:\.self) { j in
                            Button { selections[i]=j } label: { HStack(alignment:.top) { Image(systemName:selections[i] == j ? "largecircle.fill.circle" : "circle"); Text(q.choices[j]).frame(maxWidth:.infinity,alignment:.leading) }.padding(10) }.buttonStyle(.bordered).disabled(model.answers.indices.contains(i) && model.answers[i] >= 0)
                        }
                        if model.answers.indices.contains(i),model.answers[i] < 0 {
                            Button("Check my answer") { if let answer=selections[i] { model.answers[i]=answer;model.save() } }.buttonStyle(.borderedProminent).disabled(selections[i] == nil)
                        }
                        if model.answers.indices.contains(i),model.answers[i] >= 0 {
                            Text(model.answers[i] == q.answer ? "Correct" : "Review the reasoning")
                            Text(q.explanation).font(.system(size:14))
                        }
                    }.padding(.vertical,8)
                    Divider()
                }
            }
            if model.busy { HStack { ProgressView(); Button("Stop AI request") { model.cancelRequest() }.buttonStyle(.bordered) } }
            Divider()
            Text(model.message).font(.system(size:14)).textSelection(.enabled)
        }.font(.system(size:16)).controlSize(.large)
    }
    private var conceptSummary:some View { summaryCards(model.conceptSummaries) }
    private var personalConceptSummary:some View { summaryCards(ConceptReviewSummary.summarize(model.personalObservations)) }
    private func summaryCards(_ summaries:[ConceptReviewSummary]) -> some View {
        ForEach(summaries) { item in
            VStack(alignment:.leading,spacing:6) {
                Label(item.concept.capitalized,systemImage:"sparkles").font(.headline)
                Text("Pending: \(item.pending) · User-reproduced: \(item.userReproduced) · Not applicable: \(item.notApplicable)")
                Text(item.userReproduced > 1 ? "Repeated user reports across distinct source snapshots; not system-verified." : "No repeated user-reproduced pattern recorded.")
                    .font(.callout).foregroundStyle(.secondary)
                Text("Counts use distinct source snapshots; edited copies may belong to the same task.").font(.caption).foregroundStyle(.secondary)
            }.padding(12).frame(maxWidth:.infinity,alignment:.leading)
                .background(Color.purple.opacity(0.06),in:RoundedRectangle(cornerRadius:12))
        }
    }

}


struct AIObservationCard:View {
    let observation:ReasoningObservation
    let onReview:(ObservationVerification) -> Void
    private var analysis:ConceptAnalysis { observation.analysis }
    var body:some View {
        VStack(alignment:.leading,spacing:12) {
            Label("Possible logic issue",systemImage:"sparkles").font(.headline).foregroundStyle(Color.purple)
            Text(observation.isDemo == true ? "AI review · simulated example" : "AI code review · DeepSeek").font(.callout)
            Text(observation.verification.label).font(.callout.bold()).foregroundStyle(Color.purple)
            Text(observation.timestamp,style:.date).font(.caption).foregroundStyle(.secondary)
            Text(analysis.concept).font(.headline)
            field("Observed code",analysis.observedCode ?? "Not separately saved in this older observation. Review the evidence below.",code:true)
            field("Possible issue",analysis.possibleIssue ?? analysis.possibleHabit)
            field("Why AI suspects this",analysis.evidence)
            field("Candidate test / counterexample · not executed",analysis.counterexample ?? "No concrete test case was saved. Analyze the source again to request one.")
            field("How to verify",analysis.verificationSteps ?? analysis.suggestedPractice)
            Text("AI has not run this code. Its explanation and predicted results may be wrong.").font(.callout).foregroundStyle(.secondary)
            if observation.decision == "Confirmed" {
                Text("Previously marked Confirm. That did not establish a test result; please review again.").font(.callout)
            }
            if observation.isDemo != true {
                VStack(alignment:.leading,spacing:8) {
                    Button("I tested it and reproduced it") { onReview(.userReproduced) }
                    Button("This does not apply") { onReview(.notApplicable) }
                    if observation.verification != .pending { Button("Mark as pending verification") { onReview(.pending) } }
                }.buttonStyle(.bordered)
            }
        }.padding(16).frame(maxWidth:.infinity,alignment:.leading)
            .background(Color.purple.opacity(0.06),in:RoundedRectangle(cornerRadius:12))
            .overlay(RoundedRectangle(cornerRadius:12).stroke(Color.purple.opacity(0.25)))
    }
    private func field(_ title:String,_ text:String,code:Bool = false) -> some View {
        VStack(alignment:.leading,spacing:4) {
            Text(title).font(.system(size:14,weight:.semibold))
            Text(text).font(.system(size:14,design:code ? .monospaced:.default)).textSelection(.enabled)
        }
    }
}
