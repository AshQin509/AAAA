import Foundation
import SwiftUI
import AppKit

@main struct ReviewStateTests {
    @MainActor static func main() throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:directory) }
        let url=directory.appendingPathComponent("reasoning.json")
        let data=Data(#"{"language":"java","concept":"Boundary conditions","possibleHabit":"Unchecked initialization","evidence":"The initial maximum is zero.","confidence":"medium","suggestedPractice":"Test negative inputs.","observedCode":"int max = 0;","possibleIssue":"All-negative arrays may incorrectly return zero.","counterexample":"Candidate input: [-5, -2]. Expected: -2. Predicted: 0. Not executed.","verificationSteps":"Run the function with [-5, -2] and compare the output to -2."}"#.utf8)
        let analysis=try JSONDecoder().decode(ConceptAnalysis.self,from:data)
        let model=ReasoningModel(storageURL:url)
        let old=ReasoningObservation(analysis:analysis,decision:"Confirmed",sourceEvent:"legacy")
        let pending=ReasoningObservation(analysis:analysis,sourceEvent:"pending")
        model.observations=[old,pending]
        model.save()
        let restored=ReasoningModel(storageURL:url)
        precondition(restored.observations.count == 2)
        precondition(restored.observations[0].verification == .pending)
        restored.review(old.id,as:.userReproduced)
        let reviewed=ReasoningModel(storageURL:url)
        precondition(reviewed.observations[0].verification == .userReproduced)
        precondition(reviewed.conceptSummaries.first?.userReproduced == 1)
        precondition(reviewed.conceptSummaries.first?.pending == 1)
        reviewed.review(pending.id,as:.notApplicable)
        precondition(reviewed.personalObservations.filter{$0.verification != .notApplicable}.count == 1)
        reviewed.showDemo=true
        precondition(reviewed.visibleObservations.isEmpty)
        precondition(reviewed.personalObservations.count == 2)
        print("PASS review persistence, legacy confirmation, separate counts, practice eligibility and demo isolation")

        // Render synthetic observations only; no user data or credentials.
        _=NSApplication.shared
        let output=URL(fileURLWithPath:CommandLine.arguments[1],isDirectory:true)
        try FileManager.default.createDirectory(at:output,withIntermediateDirectories:true)
        reviewed.showDemo=false
        for section in [0,1,3] {
            let content=ScrollView { ReasoningView(model:reviewed,section:section).padding(20) }
                .frame(width:620,height:720).background(Color.white).preferredColorScheme(.light)
            let view=NSHostingView(rootView:content)
            view.frame=NSRect(x:0,y:0,width:620,height:720)
            let window=NSWindow(contentRect:view.frame,styleMask:[.borderless],backing:.buffered,defer:false)
            window.contentView=view
            view.layoutSubtreeIfNeeded()
            if let bitmap=view.bitmapImageRepForCachingDisplay(in:view.bounds) {
                view.cacheDisplay(in:view.bounds,to:bitmap)
                try bitmap.representation(using:.png,properties:[:])?.write(to:output.appendingPathComponent("section-\(section).png"))
            }
            window.contentView=nil
        }
        print("Rendered synthetic Coach, Habits and Progress previews")
    }
}
