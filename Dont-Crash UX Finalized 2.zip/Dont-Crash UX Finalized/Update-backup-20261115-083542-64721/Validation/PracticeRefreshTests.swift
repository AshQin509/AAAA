import Foundation
import SwiftUI

@main struct PracticeRefreshTests {
    @MainActor static func main() async throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at:directory) }
        let url=directory.appendingPathComponent("reasoning.json")
        var requests=0
        var invalid=false
        var inputs:[String]=[]
        let model=ReasoningModel(storageURL:url,practiceRequester:{ _,input in
            requests += 1;inputs.append(input)
            let exercises=(0..<(invalid ? 2:3)).map { i in
                ["question":"Set \(requests), question \(i)","choices":["A","B","C","D"],"answer":i,"explanation":"Reasoning"] as [String:Any]
            }
            return try JSONSerialization.data(withJSONObject:["exercises":exercises])
        })
        let analysis=try JSONDecoder().decode(ConceptAnalysis.self,from:Data(#"{"language":"java","concept":"Boundary conditions","possibleHabit":"Initialization assumptions","evidence":"Initial value is zero","confidence":"medium","suggestedPractice":"Check negative inputs"}"#.utf8))
        model.observations=[ReasoningObservation(analysis:analysis)]
        model.consent=true
        await generate(model)
        precondition(requests == 1 && model.exercises.count == 3)
        let firstDay=model.day, firstID=model.practiceSetID
        model.answers[0]=1;model.save()
        await generate(model)
        precondition(requests == 2,"A same-day refresh must make another request")
        precondition(model.day == firstDay && model.exercises.count == 3)
        precondition(model.practiceSetID != firstID)
        precondition(model.answers == [-1,-1,-1])
        precondition(model.archive.count == 1 && model.archive[0].answers[0] == 1)
        let context=try JSONSerialization.jsonObject(with:Data(inputs[1].utf8)) as! [String:Any]
        precondition((context["previousQuestions"] as? [[String:Any]])?.count == 3)
        model.answers[0]=2
        let before=model.exercises
        invalid=true
        await generate(model)
        precondition(model.exercises == before && model.answers[0] == 2)
        precondition(model.archive.count == 1,"Failed refresh must not archive or replace the current set")
        invalid=false
        await generate(model)
        precondition(requests == 4 && model.archive.count == 2 && model.exercises.count == 3)
        let restored=ReasoningModel(storageURL:url)
        precondition(restored.archive.count == 2 && restored.answers == [-1,-1,-1])
        print("PASS repeated same-day refresh, three questions per set, answer reset, archive persistence, prior-question context and failed-refresh preservation")
    }
    @MainActor static func generate(_ model:ReasoningModel) async {
        model.practice()
        for _ in 0..<200 {
            if !model.busy { return }
            try? await Task.sleep(nanoseconds:10_000_000)
        }
        preconditionFailure("Mock practice request timed out")
    }
}
