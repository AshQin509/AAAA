# Compiler diagnostics and AI observations

The Coach now shows an orange local-javac result section before the purple AI review section. Compilation success means only that this single-file compilation reported no errors; logic and runtime behavior are explicitly unverified. Compiler history uses “last reported” and “no longer reported,” not mastery or resolved-logic claims.

AI observations show source, verification status, code evidence, a possible issue, reasoning, an unexecuted candidate counterexample, and verification steps. New responses must supply the additional fields. Old saved observations still decode and display explicit fallbacks for missing fields.

Review actions are “I tested it and reproduced it,” “This does not apply,” and a reset to pending. Reproduction is a user report, never system verification. Old Confirm decisions remain saved but count as pending because the old button did not ask whether a test was run; old Dismiss decisions map to not applicable.

Habits and Progress display compiler statistics separately from AI observations. Concept summaries separate pending, user-reproduced, and not-applicable counts across distinct source snapshots. Only user-reproduced snapshots contribute to repeated-user-report labels. Pending observations remain available for exploratory practice, with their verification status included in AI requests. Example history remains separate.

DeepSeek, OpenAI, Databricks, their existing setup controls, model identifiers, Keychain services, and network endpoints are unchanged. No real API request or credential inspection was performed.

Validation: complete native app compiled for Apple Silicon, ad-hoc signing verified; 34 XCTest cases executed (30 passed, 4 JDK-dependent cases skipped, zero failures). Additional native model checks verified history round trips, legacy decisions, user review persistence, separated counts, practice eligibility and demo isolation. Synthetic Coach, Habits and Progress views were rendered for layout inspection. These checks do not establish live model accuracy or full cross-editor compatibility.

## Comic card refinement

Coach and Habits now share a matched pair of expandable comic cards: Java Compiler uses bright yellow and AI Suggestions uses green, with the same 22-point rounded heading, dark outlines, offset shadows, badges and equal collapsed heights. Source controls are grouped into a disclosure so both cards fit in the Coach window. Detailed code review and history remain available inside the cards.

Removed the source-connection/repeated-diagnostic sentence requested in p1. The empty-statistics sentence from p2 is now gated on an available source, a completed clean compiler check for the exact current source fingerprint, no ongoing check and empty statistics. It is hidden for no source, pending checks, changed source, failed checks and disconnection.

Additional checks: synthetic native AppModel visibility assertions covered no source, unchecked source, a clean result, checking, edited text and disconnection. Both full Coach and Habits layouts were rendered and visually inspected; collapsed card heights were programmatically compared. No live API request was made.

## Readability, expansion and practice refresh

Card summaries now use 18-point text. All expandable rows use 17-point bold labels and a full-width button with a minimum 44-point hit area; either the chevron or label toggles expansion. Removed the CHECK!/IDEA! header badges. The main navigation is a centered, 16-point tab bar with no visible Page label.

Practice now contains two equal-level tabs: Daily Practice first and Code-based Practice second. Daily Practice generates exactly three questions per request and supports unlimited same-day refreshes. A successful refresh archives the previous set and submitted answers, resets selections and hints, and installs a fresh set. Invalid or failed responses leave the current questions and answers intact. Previous questions are included as model context to request new examples. Progress no longer contains the Java Compiler card.

Mock-only refresh checks verified repeated same-day requests, exactly three questions, answer reset, history restoration, previous-question context and failed-refresh preservation. Coach, Habits, Practice and Progress were rendered from synthetic state for visual review. No live model request was made.

## Source controls and lighter typography

Reduced the navigation, card heading, subtitle, summary and expandable-row label sizes by one point, with lighter weights. Source connection controls are permanently visible. Removed the general connection-hint text and the captured-snapshot preview button, its action, and its fallback messaging. Source content now transfers directly to the AI review editor when a new or changed source is captured, with the existing 30 KB limit. Unchanged captures do not overwrite manual edits in the review editor. AI requests still require the user's explicit analysis action.

The existing source-state and matched-card layout checks passed, and the updated Coach layout was rendered and inspected.

## Coaching AI setup and card headings

Java Compiler and AI Suggestions headings now use 20-point regular rounded text. The AI card subtitle is simply “AI code review.”

The previous “AI setup is needed on this Mac” message was raised by local credential validation before any network request, when the main coaching credential was missing, empty or contained line breaks. Main coaching and legacy OpenAI/Databricks tools use different Keychain service identifiers. A metadata-only check from the current execution environment returned an unavailable status and did not establish the actual user Keychain state; no secret was requested or printed.

Added Configure AI in Coach and Configure coaching AI credential in Settings > AI connection. Both open the existing secure in-app credential dialog through a local notification. Missing and invalid credentials now produce distinct actionable messages, without exposing the value. No key is saved until the user enters one and clicks Save; no network request is sent by configuration. Credential-validation tests cover missing, whitespace-only and malformed values.
