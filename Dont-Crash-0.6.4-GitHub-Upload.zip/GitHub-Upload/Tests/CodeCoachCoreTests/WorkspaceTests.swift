import XCTest
@testable import CodeCoachCore

final class WorkspaceTests:XCTestCase {
    func testNormalizesWorkspaceURLsAndKeepsLegacyCredentialIdentity() throws {
        let old=try DatabricksWorkspace("  HTTPS://"+DatabricksConfig.host.uppercased()+"/?o=123#workspace  ")
        XCTAssertEqual(old.host,DatabricksConfig.host)
        XCTAssertEqual(old.endpoint,DatabricksConfig.endpoint)
        XCTAssertEqual(old.credentialService,DatabricksConfig.credentialService)
        XCTAssertEqual(try DatabricksWorkspace("adb-123.azuredatabricks.net").baseURL,"https://adb-123.azuredatabricks.net")
        XCTAssertEqual(try DatabricksWorkspace("https://123.gcp.databricks.com/editor/notebooks/1").host,"123.gcp.databricks.com")
        let other=try DatabricksWorkspace("dbc-second.cloud.databricks.com")
        XCTAssertNotEqual(AIProvider.databricks.credentialService(workspace:old),AIProvider.databricks.credentialService(workspace:other))
        XCTAssertEqual(AIProvider.openai.credentialService(workspace:old),AIProvider.openai.credentialService(workspace:other))
    }
    func testRejectsInvalidOrUnexpectedDestinations() {
        for value in ["","http://dbc-test.cloud.databricks.com","https://example.com","https://cloud.databricks.com.evil.example","https://user:password@dbc-test.cloud.databricks.com","https://dbc-test.cloud.databricks.com:8080"] {
            XCTAssertThrowsError(try DatabricksWorkspace(value),value)
        }
    }
    func testPracticeAndConnectionUseCustomWorkspace() async throws {
        let workspace=try DatabricksWorkspace("dbc-second.cloud.databricks.com")
        for connectionTest in [false,true] {
            let config=URLSessionConfiguration.ephemeral;config.protocolClasses=[MockProtocol.self]
            MockProtocol.handler={ request in
                XCTAssertEqual(request.url,workspace.endpoint)
                XCTAssertEqual(request.value(forHTTPHeaderField:"Authorization"),"Bearer dummy")
                let text:String
                if connectionTest { text="{\"ready\":true}" }
                else {
                    let quiz=Quiz(question:"Independent example",choices:["A","B","C","D"],answer:0,explanation:"Reason")
                    let items=Array(repeating:PracticeItem(topic:"Types and conversions",quiz:quiz),count:3)
                    text=String(decoding:try JSONEncoder().encode(["exercises":items]),as:UTF8.self)
                }
                return (200,try JSONSerialization.data(withJSONObject:["choices":[["finish_reason":"stop","message":["content":text]]]]))
            }
            let client=DatabricksClient(session:URLSession(configuration:config),provider:.databricks,workspace:workspace)
            if connectionTest { try await client.testConnection(key:"dummy",model:"chosen-model") }
            else {
                let items=try await client.generatePractice(stats:[TopicStat(topic:"Types and conversions",occurrences:0,answered:0,correct:0)],key:"dummy",model:"chosen-model")
                XCTAssertEqual(items.count,3)
            }
        }
    }
}
