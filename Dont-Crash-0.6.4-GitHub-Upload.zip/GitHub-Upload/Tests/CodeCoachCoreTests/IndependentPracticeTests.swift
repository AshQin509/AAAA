import XCTest
@testable import CodeCoachCore

final class IndependentPracticeTests:XCTestCase {
    func testMixedAndTopicHaveDifferentCountsAndConceptScope() throws {
        let type="Types and conversions",scope="Symbols and scope"
        func item(_ topic:String) -> PracticeItem { PracticeItem(topic:topic,quiz:Quiz(question:"Question",choices:["A","B","C","D"],answer:0,explanation:"Reason")) }
        XCTAssertEqual(try IndependentPractice.validate([item(type)],allowedTopics:[type],mode:.topic).count,1)
        XCTAssertThrowsError(try IndependentPractice.validate([item(type),item(type),item(type)],allowedTopics:[type],mode:.topic))
        XCTAssertThrowsError(try IndependentPractice.validate([item(type)],allowedTopics:[type,scope],mode:.topic))
        XCTAssertEqual(try IndependentPractice.validate([item(type),item(scope),item(type)],allowedTopics:[type,scope],mode:.mixed).count,3)
        XCTAssertThrowsError(try IndependentPractice.validate([item(type)],allowedTopics:[type],mode:.mixed))
        XCTAssertThrowsError(try IndependentPractice.validate([item(type),item(type),item(type)],allowedTopics:[type,scope],mode:.mixed))
        XCTAssertTrue(IndependentPractice.instructions(for:.mixed).contains("ALL supplied Notes"))
        XCTAssertTrue(IndependentPractice.instructions(for:.topic).contains("exactly ONE"))
    }
    func testTopicRequestsReturnOneQuestionAcrossAllProviders() async throws {
        for provider in AIProvider.allCases {
            let config=URLSessionConfiguration.ephemeral;config.protocolClasses=[MockProtocol.self]
            MockProtocol.handler={ request in
                let body=try self.body(request)
                let instructions=(body["instructions"] as? String) ?? (body["messages"] as? [[String:String]])?.first?["content"]
                XCTAssertTrue(instructions?.contains("exactly ONE") == true)
                let input=(body["input"] as? String) ?? (body["messages"] as? [[String:String]])?.last?["content"]
                let stats=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(try XCTUnwrap(input).utf8)) as? [[String:Any]])
                XCTAssertEqual(stats.count,1)
                let q=PracticeItem(topic:self.stat.topic,quiz:Quiz(question:"Topic question",choices:["A","B","C","D"],answer:0,explanation:"Reason"))
                let text=String(decoding:try JSONEncoder().encode(["exercises":[q]]),as:UTF8.self)
                if provider == .openai { return (200,try JSONSerialization.data(withJSONObject:["status":"completed","output":[["content":[["type":"output_text","text":text]]]]])) }
                return (200,try JSONSerialization.data(withJSONObject:["choices":[["finish_reason":"stop","message":["content":text]]]]))
            }
            let items=try await DatabricksClient(session:URLSession(configuration:config),provider:provider).generatePractice(stats:[stat],key:"dummy",model:"selected",mode:.topic)
            XCTAssertEqual(items.count,1)
        }
    }
    private func body(_ request:URLRequest) throws -> [String:Any] {
        var data=request.httpBody
        if data == nil,let stream=request.httpBodyStream {
            stream.open();defer { stream.close() };var buffer=[UInt8](repeating:0,count:4096);var all=Data()
            while stream.hasBytesAvailable { let n=stream.read(&buffer,maxLength:buffer.count);if n<=0 { break };all.append(buffer,count:n) };data=all
        }
        return try XCTUnwrap(JSONSerialization.jsonObject(with:try XCTUnwrap(data)) as? [String:Any])
    }
    private let stat=TopicStat(topic:"Types and conversions",occurrences:2,answered:3,correct:1)
    func testOnlyKnownTopicsAndAggregateCountsCanBeSent() throws {
        let payload=try IndependentPractice.payload([stat])
        let values=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(payload.utf8)) as? [[String:Any]])
        XCTAssertEqual(Set(values[0].keys),Set(["topic","occurrences","answered","correct"]))
        XCTAssertThrowsError(try IndependentPractice.payload([TopicStat(topic:"/Users/student/Secret.java",occurrences:0,answered:0,correct:0)]))
        XCTAssertThrowsError(try IndependentPractice.payload([TopicStat(topic:stat.topic,occurrences:0,answered:1,correct:2)]))
        XCTAssertThrowsError(try IndependentPractice.payload([stat,stat]))
    }
    func testThreeQuestionsAndSelectedConceptAreEnforced() throws {
        let quiz=Quiz(question:"Independent question",choices:["A","B","C","D"],answer:0,explanation:"Reason")
        let items=Array(repeating:PracticeItem(topic:stat.topic,quiz:quiz),count:3)
        XCTAssertEqual(try IndependentPractice.validate(items,allowedTopics:[stat.topic]).count,3)
        XCTAssertThrowsError(try IndependentPractice.validate(Array(items.prefix(2)),allowedTopics:[stat.topic]))
        XCTAssertThrowsError(try IndependentPractice.validate(items,allowedTopics:["Boundary conditions"]))
    }
    func testProvidersShareTheSafePracticeContract() async throws {
        for provider in AIProvider.allCases {
            let config=URLSessionConfiguration.ephemeral;config.protocolClasses=[MockProtocol.self]
            let session=URLSession(configuration:config)
            MockProtocol.handler={ request in
                let body=try self.body(request)
                XCTAssertEqual(body["model"] as? String,"selected-model")
                XCTAssertEqual(request.value(forHTTPHeaderField:"Authorization"),"Bearer dummy")
                let input:String
                if provider == .openai {
                    XCTAssertEqual(request.url?.host,"api.openai.com")
                    input=try XCTUnwrap(body["input"] as? String)
                    XCTAssertEqual(body["store"] as? Bool,false)
                } else {
                    XCTAssertEqual(request.url?.host,provider == .deepseek ? "api.deepseek.com":DatabricksConfig.host)
                    input=try XCTUnwrap((body["messages"] as? [[String:String]])?.last?["content"])
                    if provider == .deepseek { XCTAssertEqual((body["response_format"] as? [String:String])?["type"],"json_object") }
                }
                let stats=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(input.utf8)) as? [[String:Any]])
                XCTAssertEqual(Set(stats[0].keys),Set(["topic","occurrences","answered","correct"]))
                let quiz=Quiz(question:"Independent example",choices:["A","B","C","D"],answer:0,explanation:"Reason")
                let items=Array(repeating:PracticeItem(topic:self.stat.topic,quiz:quiz),count:3)
                let text=String(decoding:try JSONEncoder().encode(["exercises":items]),as:UTF8.self)
                if provider == .openai {
                    return (200,try JSONSerialization.data(withJSONObject:["status":"completed","output":[["content":[["type":"output_text","text":text]]]]]))
                }
                return (200,try JSONSerialization.data(withJSONObject:["choices":[["finish_reason":"stop","message":["content":text]]]]))
            }
            let result=try await DatabricksClient(session:session,provider:provider).generatePractice(stats:[stat],key:"dummy",model:"selected-model")
            XCTAssertEqual(result.count,3);session.invalidateAndCancel()
        }
        XCTAssertEqual(AIProvider.deepseek.credentialService,"com.stucksense.deepseek")
        XCTAssertNotEqual(AIProvider.databricks.credentialService,AIProvider.openai.credentialService)
    }
    func testNotesAggregateSourcesAndPreserveOldAnswers() throws {
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:dir) }
        let store=try ErrorStore(url:dir.appendingPathComponent("learning.sqlite"))
        let d=Diagnostic(file:"Private.java",line:1,code:"compiler.err.prob.found.req",message:"sensitive diagnostic")
        try store.reconcile(project:"first",diagnostics:[d]);try store.reconcile(project:"second",diagnostics:[d])
        try store.reconcile(project:"second",diagnostics:[]);try store.reconcile(project:"second",diagnostics:[d])
        try store.answer(id:"a",project:"first",topic:d.category,correct:true)
        try store.answer(id:"b",project:"second",topic:d.category,correct:false)
        let note=try XCTUnwrap(store.allStats().first)
        XCTAssertEqual(note.occurrences,3);XCTAssertEqual(note.answered,2);XCTAssertEqual(note.correct,1)
        let payload=try IndependentPractice.payload([note])
        XCTAssertFalse(payload.contains("sensitive"));XCTAssertFalse(payload.contains("Private.java"))
    }
    func testLegacyPracticeTotalsIncludeAnswersWithoutDiagnosticRows() throws {
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:dir) }
        let store=try ErrorStore(url:dir.appendingPathComponent("learning.sqlite"))
        XCTAssertEqual(try store.legacyPracticeSummary(),LegacyPracticeSummary())
        try store.answer(id:"one",project:"old",topic:"Types and conversions",correct:true)
        try store.answer(id:"two",project:"old",topic:"Symbols and scope",correct:false)
        let summary=try store.legacyPracticeSummary()
        XCTAssertEqual(summary.answered,2);XCTAssertEqual(summary.correct,1)
        XCTAssertEqual(Set(summary.topics),Set(["Types and conversions","Symbols and scope"]))
    }
    func testFailedAndTruncatedResponsesAreRejectedWithoutLeakingBodies() async throws {
        for provider in AIProvider.allCases {
            for code in [401,403,404,429] {
                let config=URLSessionConfiguration.ephemeral;config.protocolClasses=[MockProtocol.self]
                MockProtocol.handler={ _ in (code,Data("private-service-response".utf8)) }
                do {
                    _=try await DatabricksClient(session:URLSession(configuration:config),provider:provider).generatePractice(stats:[stat],key:"dummy",model:"model")
                    XCTFail("Expected HTTP error")
                } catch { XCTAssertFalse(error.localizedDescription.contains("private-service-response")) }
            }
        }
        for provider in AIProvider.allCases {
            let config=URLSessionConfiguration.ephemeral;config.protocolClasses=[MockProtocol.self]
            MockProtocol.handler={ _ in
                if provider == .openai { return (200,Data(#"{"status":"incomplete","output":[]}"#.utf8)) }
                return (200,Data(#"{"choices":[{"finish_reason":"length","message":{"content":"{}"}}]}"#.utf8))
            }
            do {
                _=try await DatabricksClient(session:URLSession(configuration:config),provider:provider).generatePractice(stats:[stat],key:"dummy",model:"model")
                XCTFail("Expected incomplete-response rejection")
            } catch {}
        }
    }
    func testConnectionUsesSelectedProviderAndModelWithoutStudentData() async throws {
        for provider in AIProvider.allCases {
            let config=URLSessionConfiguration.ephemeral;config.protocolClasses=[MockProtocol.self]
            MockProtocol.handler={ request in
                let body=try self.body(request)
                XCTAssertEqual(body["model"] as? String,"chosen-model")
                let input=(body["input"] as? String) ?? (body["messages"] as? [[String:String]])?.last?["content"]
                XCTAssertEqual(input,"Connection test. No project data is included.")
                if provider == .openai {
                    return (200,Data(#"{"status":"completed","output":[{"content":[{"type":"output_text","text":"{\"ready\":true}"}]}]}"#.utf8))
                }
                return (200,Data(#"{"choices":[{"finish_reason":"stop","message":{"content":"{\"ready\":true}"}}]}"#.utf8))
            }
            try await DatabricksClient(session:URLSession(configuration:config),provider:provider).testConnection(key:"dummy",model:"chosen-model")
        }
    }
}
