import XCTest
@testable import CodeCoachCore
final class ReasoningTests:XCTestCase {
 func testCredentialSetupFailuresAreActionableAndNeverExposeTheValue() throws {
  for value:String? in [nil,"","   "] {
   XCTAssertThrowsError(try DeepSeekClient.validatedCredential(value)) { error in
    XCTAssertTrue(error.localizedDescription.contains("Settings > AI connection"))
    XCTAssertTrue(error.localizedDescription.contains("No coaching AI credential"))
   }
  }
  XCTAssertThrowsError(try DeepSeekClient.validatedCredential("dummy-secret\nvalue")) { error in
   XCTAssertTrue(error.localizedDescription.contains("invalid format"))
   XCTAssertFalse(error.localizedDescription.contains("dummy-secret"))
  }
  XCTAssertEqual(try DeepSeekClient.validatedCredential("  dummy-test-value  "),"dummy-test-value")
 }
 private func oldAnalysis() throws -> ConceptAnalysis {
  try JSONDecoder().decode(ConceptAnalysis.self,from:Data(#"{"language":"java","concept":"Boundary conditions","possibleHabit":"Unchecked initialization","evidence":"max starts at zero","confidence":"medium","suggestedPractice":"Try negative inputs"}"#.utf8))
 }
 func testLegacyHistoryDoesNotBecomeAReproducedTest() throws {
  let old=ReasoningObservation(analysis:try oldAnalysis(),decision:"Confirmed",sourceEvent:"a")
  let decoded=try JSONDecoder().decode(ReasoningObservation.self,from:JSONEncoder().encode(old))
  XCTAssertEqual(decoded.decision,"Confirmed")
  XCTAssertEqual(decoded.verification,.pending)
  XCTAssertEqual(ObservationVerification(savedDecision:"Dismissed"),.notApplicable)
  XCTAssertEqual(ObservationVerification(savedDecision:"unknown-future-status"),.pending)
  XCTAssertNil(decoded.analysis.counterexample)
 }
 func testNewFeedbackRequiresActionableGroundingButOldHistoryStillLoads() throws {
  var analysis=try oldAnalysis()
  XCTAssertNoThrow(try analysis.validated())
  XCTAssertThrowsError(try analysis.validated(requireGrounding:true))
  analysis.observedCode="int max = 0;";analysis.possibleIssue="All-negative inputs may return zero."
  analysis.counterexample="Try [-5,-2]; expected -2, predicted 0 (not executed)."
  analysis.verificationSteps="Run the method with that array and compare the result."
  XCTAssertNoThrow(try analysis.validated(requireGrounding:true))
  XCTAssertEqual(try JSONDecoder().decode(ConceptAnalysis.self,from:JSONEncoder().encode(analysis)),analysis)
 }
 func testSummarySeparatesPendingFromReproducedAndDeduplicatesSources() throws {
  let a=try oldAnalysis()
  let observations=[
   ReasoningObservation(analysis:a,sourceEvent:"pending"),
   ReasoningObservation(analysis:a,decision:"Confirmed",sourceEvent:"old-confirm"),
   ReasoningObservation(analysis:a,decision:"UserReproduced",sourceEvent:"tested"),
   ReasoningObservation(analysis:a,sourceEvent:"tested"),
   ReasoningObservation(analysis:a,decision:"UserReproduced",sourceEvent:"tested"),
   ReasoningObservation(analysis:a,decision:"NotApplicable",sourceEvent:"dismissed")]
  let summary=try XCTUnwrap(ConceptReviewSummary.summarize(observations).first)
  XCTAssertEqual(summary.pending,2)
  XCTAssertEqual(summary.userReproduced,1)
  XCTAssertEqual(summary.notApplicable,1)
  // Different pending code snapshots alone never establish repeated reproduction.
  XCTAssertEqual(ConceptReviewSummary.summarize(Array(observations.prefix(2))).first?.userReproduced,0)
 }
 func testValidResponse() throws {
  let data=Data(#"{"choices":[{"finish_reason":"stop","message":{"content":"{\"ready\":true}"}}]}"#.utf8)
  XCTAssertEqual(String(decoding:try DeepSeekClient.parse(data),as:UTF8.self),#"{"ready":true}"#)
 }
 func testMalformedEmptyAndTruncated() {
  for text in ["not JSON",#"{"choices":[]}"#,#"{"choices":[{"finish_reason":"length","message":{"content":"{}"}}]}"#,#"{"choices":[{"finish_reason":"stop","message":{"content":""}}]}"#] {
   XCTAssertThrowsError(try DeepSeekClient.parse(Data(text.utf8)))
  }
 }
 func testConceptRepresentation() throws {
  let data=Data(#"{"language":"java","concept":"Boundary conditions","possibleHabit":"Unchecked initialization assumptions","evidence":"max starts at zero","confidence":"medium","suggestedPractice":"Consider an all-negative array"}"#.utf8)
  let analysis=try JSONDecoder().decode(ConceptAnalysis.self,from:data).validated()
  XCTAssertEqual(analysis.concept,"Boundary conditions")
  // This tests schema validation, not live AI classification.
 }
}
