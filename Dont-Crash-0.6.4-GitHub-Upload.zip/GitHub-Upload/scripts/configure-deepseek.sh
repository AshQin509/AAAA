#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
"$ROOT/scripts/build-app.sh"
"$ROOT/build/CodeCoach.app/Contents/MacOS/CodeCoach"

echo "Choose your AI service and save its credential in Settings."
