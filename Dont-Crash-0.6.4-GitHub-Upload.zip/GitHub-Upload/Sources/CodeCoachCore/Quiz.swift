import Foundation
import Security
import LocalAuthentication

public struct Quiz: Codable, Equatable, Sendable {
    public let question: String
    public let choices: [String]
    public let answer: Int
    public let explanation: String
    public init(question: String, choices: [String], answer: Int, explanation: String) { self.question=question; self.choices=choices; self.answer=answer; self.explanation=explanation }
    public func validated() throws -> Quiz {
        guard !question.isEmpty, question.count <= 4000, choices.count == 4, Set(choices).count == 4, choices.allSatisfy({ !$0.isEmpty && $0.count <= 2000 }), (0..<4).contains(answer), !explanation.isEmpty, explanation.count <= 6000 else { throw CoachError.message("The AI returned an invalid question. Please retry.") }
        return self
    }
}
public enum Keychain {
    private static func query(service:String) -> [String:Any] { [kSecClass as String:kSecClassGenericPassword, kSecAttrService as String:service, kSecAttrAccount as String:"api-key"] }
    /// Startup checks existence without requesting the secret or displaying a Keychain authorization dialog.
    public static func contains(service:String="com.codecoach.mac.openai") throws -> Bool {
        var q=query(service:service)
        q[kSecMatchLimit as String]=kSecMatchLimitOne
        let context=LAContext();context.interactionNotAllowed=true
        q[kSecUseAuthenticationContext as String]=context
        let status=SecItemCopyMatching(q as CFDictionary,nil)
        if status == errSecSuccess { return true }
        if status == errSecItemNotFound { return false }
        throw CoachError.message(status == errSecInteractionNotAllowed ? "Unlock Keychain, then reopen the app." : "Could not check Keychain credential status (\(status)).")
    }
    public static func read(service:String="com.codecoach.mac.openai") throws -> String? {
        var q=query(service:service); q[kSecReturnData as String]=true; q[kSecMatchLimit as String]=kSecMatchLimitOne
        var item: CFTypeRef?; let status=SecItemCopyMatching(q as CFDictionary,&item)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data=item as? Data else { throw CoachError.message("Could not read Keychain (\(status)). Check system authorization.") }
        return String(data:data,encoding:.utf8)
    }
    public static func save(_ key: String,service:String="com.codecoach.mac.openai") throws {
        let data = Data(key.utf8)
        let status = SecItemUpdate(query(service:service) as CFDictionary, [kSecValueData as String:data] as CFDictionary)
        if status == errSecItemNotFound {
            var q=query(service:service); q[kSecValueData as String]=data; q[kSecAttrAccessible as String]=kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            guard SecItemAdd(q as CFDictionary,nil) == errSecSuccess else { throw CoachError.message("Could not save the API key to Keychain.") }
        } else if status != errSecSuccess { throw CoachError.message("Could not update the API key (\(status)).") }
    }
    public static func delete(service:String="com.codecoach.mac.openai") throws { let s=SecItemDelete(query(service:service) as CFDictionary); guard s == errSecSuccess || s == errSecItemNotFound else { throw CoachError.message("Could not delete the API key (\(s)).") } }
}
public struct PracticeItem:Codable,Equatable,Sendable {
    public let topic:String
    public let quiz:Quiz
    public init(topic:String,quiz:Quiz) { self.topic=topic;self.quiz=quiz }
}
public enum PracticeMode:String,Codable,Sendable {
    case mixed="Mixed Practice",topic="Topic Practice"
    public var questionCount:Int { self == .mixed ? 3:1 }
}
public enum IndependentPractice {
    public static let topics=["Symbols and scope","Types and conversions","Methods and arguments","Static and instance members","Syntax and structure","Java fundamentals","Loops and control flow","Boundary conditions","Arrays and indexing"]
    private static let commonInstructions="Generate independent beginner Java multiple-choice exercises. Input contains only topic names and aggregate diagnostic/answer counts, never student code. Use only the provided topics and vary the examples. Invent new standalone examples and data; do not reconstruct, solve or repair a student's assignment. Adjust difficulty gently using answered/correct counts; diagnostic frequency is not ability or mastery. Each item has topic and quiz {question,choices,answer,explanation}; choices has four distinct options, answer is zero-based 0..3. Explain the correct answer and why the alternatives differ. Never claim execution or a verified runtime test. Respond in English and JSON only."
    public static func instructions(for mode:PracticeMode) -> String {
        let task=mode == .mixed ? "Mixed Practice: consider ALL supplied Notes concepts and their diagnostic/answer counts. Generate exactly THREE related independent questions, covering min(3, number of supplied concepts) different concepts. Prioritize frequent diagnostic categories and concepts with lower practice accuracy when choosing from a longer list." : "Topic Practice: generate exactly ONE independent question on the SINGLE supplied concept. Do not generate a three-question set."
        return task+" "+commonInstructions
    }
    public static func payload(_ stats:[TopicStat]) throws -> String {
        guard !stats.isEmpty,stats.count <= topics.count,Set(stats.map(\.topic)).count == stats.count,
              stats.allSatisfy({topics.contains($0.topic) && $0.occurrences >= 0 && $0.answered >= 0 && $0.correct >= 0 && $0.correct <= $0.answered}) else {
            throw CoachError.message("Choose a supported practice topic. Only concept names and aggregate counts can be sent.")
        }
        return String(decoding:try JSONEncoder().encode(stats),as:UTF8.self)
    }
    public static func validate(_ items:[PracticeItem],allowedTopics:[String],mode:PracticeMode = .mixed) throws -> [PracticeItem] {
        guard items.count == mode.questionCount else { throw CoachError.message("Expected \(mode.questionCount) question(s) for \(mode.rawValue). Your current questions were kept; retry.") }
        guard mode != .topic || allowedTopics.count == 1 else { throw CoachError.message("Topic Practice requires exactly one selected concept.") }
        for item in items {
            guard topics.contains(item.topic),allowedTopics.contains(item.topic) else { throw CoachError.message("AI returned a question outside the selected topics. Retry.") }
            _=try item.quiz.validated()
        }
        if mode == .mixed {
            guard Set(items.map(\.topic)).count >= min(3,Set(allowedTopics).count) else { throw CoachError.message("Mixed Practice must sample several of your Notes concepts. Retry.") }
        }
        return items
    }
}
