import Foundation
public struct ConceptAnalysis: Codable, Equatable {
    public let language:String
    public let concept:String
    public let possibleHabit:String
    public let evidence:String
    public let confidence:String
    public let suggestedPractice:String
    // Optional for previously saved analyses; required for new model responses.
    public var observedCode:String? = nil
    public var possibleIssue:String? = nil
    public var counterexample:String? = nil
    public var verificationSteps:String? = nil
    public func validated(requireGrounding:Bool = false) throws -> Self {
        guard [language,concept,possibleHabit,evidence,suggestedPractice].allSatisfy({ !$0.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty && $0.count < 6000 }), ["low","medium","high"].contains(confidence) else { throw CoachError.message("Incomplete conceptual feedback. Please retry.") }
        if requireGrounding {
            guard [observedCode,possibleIssue,counterexample,verificationSteps].allSatisfy({ value in
                guard let value else { return false }
                return !value.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty && value.count < 6000
            }) else { throw CoachError.message("AI feedback needs code evidence, a possible issue, a test case, and verification steps. Please retry.") }
        }
        return self
    }
}

public enum ObservationVerification:String {
    case pending="Unreviewed", userReproduced="UserReproduced", notApplicable="NotApplicable"
    public init(savedDecision:String) {
        switch savedDecision {
        case Self.userReproduced.rawValue: self = .userReproduced
        case Self.notApplicable.rawValue,"Dismissed": self = .notApplicable
        // Old Confirm buttons did not ask whether the user ran a test.
        default: self = .pending
        }
    }
    public var label:String {
        switch self {
        case .pending: return "Not run or verified"
        case .userReproduced: return "User reports reproduced · not system-verified"
        case .notApplicable: return "User reports not applicable"
        }
    }
}
public struct ReasoningObservation:Codable,Identifiable {
    public var id:UUID
    public var timestamp:Date
    public var analysis:ConceptAnalysis
    public var decision:String
    public var sourceEvent:String?
    public var isDemo:Bool?
    public init(id:UUID = UUID(),timestamp:Date = Date(),analysis:ConceptAnalysis,decision:String = "Unreviewed",sourceEvent:String? = nil,isDemo:Bool? = nil) {
        self.id=id;self.timestamp=timestamp;self.analysis=analysis;self.decision=decision;self.sourceEvent=sourceEvent;self.isDemo=isDemo
    }
    public var verification:ObservationVerification { ObservationVerification(savedDecision:decision) }
}
public struct ConceptReviewSummary:Identifiable {
    public let concept:String
    public let pending:Int
    public let userReproduced:Int
    public let notApplicable:Int
    public var id:String { concept }
    public static func summarize(_ observations:[ReasoningObservation]) -> [Self] {
        Dictionary(grouping:observations,by:{$0.analysis.concept.trimmingCharacters(in:.whitespacesAndNewlines).lowercased()}).map { concept,items in
            let events=Dictionary(grouping:items,by:{$0.sourceEvent ?? $0.id.uuidString})
            var pending=0, reproduced=0, dismissed=0
            for event in events.values {
                if event.contains(where:{$0.verification == .userReproduced}) { reproduced += 1 }
                else if event.contains(where:{$0.verification == .pending}) { pending += 1 }
                else { dismissed += 1 }
            }
            return Self(concept:concept,pending:pending,userReproduced:reproduced,notApplicable:dismissed)
        }.sorted{$0.concept < $1.concept}
    }
}
private final class DeepSeekRedirectGuard:NSObject,URLSessionTaskDelegate,@unchecked Sendable {
    func urlSession(_ session:URLSession,task:URLSessionTask,willPerformHTTPRedirection response:HTTPURLResponse,newRequest request:URLRequest,completionHandler:@escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
public struct DeepSeekClient {
    public static let service="com.stucksense.deepseek"
    public let session:URLSession
    public init(session:URLSession? = nil) { self.session=session ?? URLSession(configuration:.ephemeral,delegate:DeepSeekRedirectGuard(),delegateQueue:nil) }
    static func validatedCredential(_ key:String?) throws -> String {
        guard let key,!key.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty else {
            throw CoachError.message("No coaching AI credential is saved. Open Settings > AI connection > Configure coaching AI credential. OpenAI/Databricks credentials are separate.")
        }
        guard !key.contains("\n"),!key.contains("\r") else {
            throw CoachError.message("The saved coaching AI credential has an invalid format. Configure it again in Settings > AI connection.")
        }
        return key.trimmingCharacters(in:.whitespaces)
    }
    public static func parse(_ data:Data) throws -> Data {
        guard data.count < 200000, let object=try JSONSerialization.jsonObject(with:data) as? [String:Any],let choices=object["choices"] as? [[String:Any]],let first=choices.first,first["finish_reason"] as? String == "stop",let message=first["message"] as? [String:Any],let text=message["content"] as? String,!text.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty else { throw CoachError.message("AI returned empty or incomplete feedback. Retry.") }
        let result=Data(text.utf8)
        guard (try? JSONSerialization.jsonObject(with:result)) != nil else { throw CoachError.message("AI feedback was malformed. Retry.") }
        return result
    }
}
