import Foundation

public struct DatabricksWorkspace:Equatable,Sendable {
    public let host:String
    public init(_ input:String) throws {
        let value=input.trimmingCharacters(in:.whitespacesAndNewlines)
        let text=value.contains("://") ? value : "https://"+value
        guard let components=URLComponents(string:text),components.scheme?.lowercased() == "https",
              components.user == nil,components.password == nil,components.port == nil || components.port == 443,
              let host=components.host?.lowercased(),
              [".cloud.databricks.com",".azuredatabricks.net",".gcp.databricks.com"].contains(where:host.hasSuffix),
              host.unicodeScalars.allSatisfy({CharacterSet(charactersIn:"abcdefghijklmnopqrstuvwxyz0123456789.-").contains($0)}) else {
            throw CoachError.message("Enter a valid HTTPS Databricks workspace URL (AWS, Azure, or GCP), without login credentials or a custom port.")
        }
        self.host=host
    }
    public var baseURL:String { "https://"+host }
    public var endpoint:URL { URL(string:baseURL+"/ai-gateway/mlflow/v1/chat/completions")! }
    public var credentialService:String { "com.codecoach.mac.databricks."+host }
}

public enum DatabricksConfig {
    public static let host = "dbc-b4f4fe67-acdc.cloud.databricks.com"
    public static let endpoint = URL(string:"https://"+host+"/ai-gateway/mlflow/v1/chat/completions")!
    public static let model = "system.ai.gpt-oss-120b"
    public static let credentialService = "com.codecoach.mac.databricks."+host
    public static let workspace = try! DatabricksWorkspace(host)
}
public enum AIProvider: String, CaseIterable, Sendable {
    case databricks = "Databricks", openai = "OpenAI", deepseek = "DeepSeek"
    public var credentialService:String {
        switch self {
        case .databricks: return DatabricksConfig.credentialService
        case .openai: return "com.codecoach.mac.openai"
        case .deepseek: return "com.stucksense.deepseek"
        }
    }
    public func credentialService(workspace:DatabricksWorkspace) -> String {
        self == .databricks ? workspace.credentialService : credentialService
    }
    public var defaultModel:String {
        switch self { case .databricks: return DatabricksConfig.model; case .openai: return "gpt-4.1-mini"; case .deepseek: return "deepseek-flash" }
    }
}

private final class RejectRedirects:NSObject,URLSessionTaskDelegate,@unchecked Sendable {
    func urlSession(_ session:URLSession,task:URLSessionTask,willPerformHTTPRedirection response:HTTPURLResponse,newRequest request:URLRequest,completionHandler:@escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
public struct DatabricksClient {
    public let provider: AIProvider
    public let session:URLSession
    public let workspace:DatabricksWorkspace
    private let ownsSession:Bool
    public init(session:URLSession? = nil, provider:AIProvider = .databricks,workspace:DatabricksWorkspace = DatabricksConfig.workspace) {
        self.workspace=workspace
        self.provider=provider
        self.ownsSession=session == nil
        self.session=session ?? URLSession(configuration:.ephemeral,delegate:RejectRedirects(),delegateQueue:nil)
    }
    public func generatePractice(stats:[TopicStat],key:String,model:String,mode:PracticeMode = .mixed) async throws -> [PracticeItem] {
        let input=try IndependentPractice.payload(stats)
        guard mode != .topic || stats.count == 1 else { throw CoachError.message("Choose one concept for Topic Practice.") }
        let quiz:[String:Any]=["type":"object","properties":["question":["type":"string"],"choices":["type":"array","items":["type":"string"]],"answer":["type":"integer"],"explanation":["type":"string"]],"required":["question","choices","answer","explanation"],"additionalProperties":false]
        let item:[String:Any]=["type":"object","properties":["topic":["type":"string","enum":stats.map(\.topic)],"quiz":quiz],"required":["topic","quiz"],"additionalProperties":false]
        let schema:[String:Any]=["type":"object","properties":["exercises":["type":"array","items":item]],"required":["exercises"],"additionalProperties":false]
        let text=try await completion(key:key,model:model,instructions:IndependentPractice.instructions(for:mode),input:input,schema:schema,name:"independent_java_practice")
        struct Response:Decodable { let exercises:[PracticeItem] }
        let items=try JSONDecoder().decode(Response.self,from:Data(text.utf8)).exercises
        return try IndependentPractice.validate(items,allowedTopics:stats.map(\.topic),mode:mode)
    }
    public func testConnection(key:String,model:String) async throws {
        let schema:[String:Any]=["type":"object","properties":["ready":["type":"boolean"]],"required":["ready"],"additionalProperties":false]
        let text=try await completion(key:key,model:model,instructions:"Reply only with JSON: {\"ready\":true}",input:"Connection test. No project data is included.",schema:schema,name:"connection_test",maxTokens:1500)
        guard let json=try? JSONSerialization.jsonObject(with:Data(text.utf8)) as? [String:Any], json["ready"] as? Bool == true else { throw CoachError.message("The service responded but did not return a valid test result.") }
    }
    private func completion(key:String,model:String,instructions:String,input:String,schema:[String:Any],name:String,maxTokens:Int=5000) async throws -> String {
        guard !key.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty, !key.contains("\n"), !key.contains("\r"), !model.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty else { throw CoachError.message("Set a valid API credential and model first.") }
        var body:[String:Any]=["model":model,"messages":[["role":"system","content":instructions],["role":"user","content":input]],"max_tokens":maxTokens,"stream":false,"response_format":["type":"json_schema","json_schema":["name":name,"strict":true,"schema":schema]]]
        if provider == .openai {
            body=["model":model,"store":false,"instructions":instructions,"input":input,"max_output_tokens":maxTokens,"text":["format":["type":"json_schema","name":name,"strict":true,"schema":schema]]]
        }
        if provider == .deepseek {
            let schemaText=String(decoding:try JSONSerialization.data(withJSONObject:schema),as:UTF8.self)
            body["response_format"]=["type":"json_object"]
            body["messages"]=[["role":"system","content":instructions+" Return JSON only matching this schema: "+schemaText],["role":"user","content":input]]
        }
        let endpoint=provider == .openai ? URL(string:"https://api.openai.com/v1/responses")! : (provider == .deepseek ? URL(string:"https://api.deepseek.com/chat/completions")! : workspace.endpoint)
        var request=URLRequest(url:endpoint);request.httpMethod="POST";request.timeoutInterval=90
        request.setValue("Bearer "+key,forHTTPHeaderField:"Authorization");request.setValue("application/json",forHTTPHeaderField:"Content-Type")
        request.httpBody=try JSONSerialization.data(withJSONObject:body)
        defer { if ownsSession { session.finishTasksAndInvalidate() } }
        let (data,response)=try await session.data(for:request)
        guard let http=response as? HTTPURLResponse else { throw CoachError.message("Databricks returned an invalid response.") }
        guard (200..<300).contains(http.statusCode) else {
            let message:String
            switch http.statusCode {
            case 401: message="Databricks Token is invalid or expired. Update your Token."
            case 403: message="This Token cannot access the model. Check workspace and model permissions."
            case 404: message="Model or service not found. Check the model ID."
            case 400: message="Databricks rejected the request. Check structured output support for this model."
            case 429: message="Databricks rate limit or quota exceeded. Retry later."
            case 300..<400: message="The service returned a redirect. Request stopped to protect your Token."
            default: message="Databricks request failed (HTTP \(http.statusCode))."
            }
            throw CoachError.message(provider == .databricks ? message : message.replacingOccurrences(of:"Databricks",with:provider.rawValue).replacingOccurrences(of:"Token",with:"API Key"))
        }
        if provider == .openai {
            guard data.count <= 200_000,
                  let json=try JSONSerialization.jsonObject(with:data) as? [String:Any],
                  json["status"] as? String == "completed",
                  let output=json["output"] as? [[String:Any]] else { throw CoachError.message("The OpenAI response is incomplete or invalid.") }
            let blocks=output.flatMap { $0["content"] as? [[String:Any]] ?? [] }
            guard !blocks.contains(where: { $0["type"] as? String == "refusal" }) else { throw CoachError.message("The model refused this request.") }
            let text=blocks.filter { $0["type"] as? String == "output_text" }.compactMap { $0["text"] as? String }.joined()
            guard !text.isEmpty else { throw CoachError.message("OpenAI returned no text.") }
            return text
        }
        guard data.count<=200_000, let json=try JSONSerialization.jsonObject(with:data) as? [String:Any], let choices=json["choices"] as? [[String:Any]], let choice=choices.first, let message=choice["message"] as? [String:Any] else { throw CoachError.message("Invalid " + provider.rawValue + " response format. Please retry.") }
        guard choice["finish_reason"] as? String == "stop" else { throw CoachError.message("Model response was truncated, refused, or incomplete. Retry.") }
        if let refusal=message["refusal"] as? String, !refusal.isEmpty { throw CoachError.message("The model refused this request. Retry or change models.") }
        let text:String
        if let content=message["content"] as? String { text=content }
        else if let blocks=message["content"] as? [[String:Any]] {
            text=blocks.filter { $0["type"] as? String == "text" }.compactMap { $0["text"] as? String }.joined(separator:"\n")
        } else { throw CoachError.message("The model returned no usable text.") }
        guard !text.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty else { throw CoachError.message("The model returned no usable text.") }
        return text
    }
}
