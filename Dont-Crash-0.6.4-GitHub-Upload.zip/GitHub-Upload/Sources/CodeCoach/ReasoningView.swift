import SwiftUI
#if SWIFT_PACKAGE
import CodeCoachCore
#endif

enum ComicReviewTheme {
    static let compiler=Color(red:1,green:0.88,blue:0.12)
    static let ai=Color(red:0.48,green:0.88,blue:0.36)
    static let ink=Color(red:0.13,green:0.16,blue:0.12)
    static let aiInk=Color(red:0.12,green:0.38,blue:0.17)
}

struct WideDisclosure<Content:View>:View {
    let title:String
    let content:Content
    @State private var expanded=false
    init(_ title:String,@ViewBuilder content:() -> Content) {
        self.title=title;self.content=content()
    }
    var body:some View {
        VStack(alignment:.leading,spacing:8) {
            Button {
                withAnimation(.easeInOut(duration:0.15)) { expanded.toggle() }
            } label: {
                HStack(spacing:9) {
                    Image(systemName:expanded ? "chevron.down" : "chevron.right")
                        .font(.system(size:13,weight:.bold)).frame(width:16)
                    Text(title).font(.system(size:16,weight:.semibold))
                    Spacer(minLength:0)
                }.padding(.vertical,8).padding(.horizontal,3)
                    .frame(maxWidth:.infinity,minHeight:44,alignment:.leading)
                    .contentShape(Rectangle())
            }.buttonStyle(.plain)
                .accessibilityLabel(title)
                .accessibilityValue(expanded ? "Expanded" : "Collapsed")
                .accessibilityHint("Click anywhere on this row to expand or collapse")
            if expanded { content }
        }
    }
}

struct CenteredTabs:View {
    let titles:[String]
    @Binding var selection:Int
    var body:some View {
        HStack(spacing:3) {
            ForEach(titles.indices,id:\.self) { index in
                Button { selection=index } label: {
                    Text(titles[index]).font(.system(size:15,weight:selection == index ? .medium:.regular))
                        .frame(maxWidth:.infinity,minHeight:36)
                        .contentShape(Rectangle())
                        .background(selection == index ? Color.white:Color.clear,in:RoundedRectangle(cornerRadius:8))
                }.buttonStyle(.plain)
                    .accessibilityAddTraits(selection == index ? .isSelected:[])
            }
        }.padding(4).frame(maxWidth:.infinity)
            .background(Color.gray.opacity(0.13),in:RoundedRectangle(cornerRadius:11))
            .foregroundStyle(ComicReviewTheme.ink)
    }
}
struct PracticeSession:Codable,Identifiable {
    var id=UUID()
    var day:String
    var exercises:[Quiz]
    var answers:[Int]
    var topics:[String]?
    var mode:String?
    var createdAt:Date? = nil
    var isResumable:Bool {
        guard let kind=PracticeMode(rawValue:mode ?? ""),exercises.count == kind.questionCount,
              let topics,topics.count == exercises.count,topics.allSatisfy({IndependentPractice.topics.contains($0)}) else { return false }
        return kind != .topic || Set(topics).count == 1
    }
    func matches(_ kind:PracticeMode,topic:String?) -> Bool {
        isResumable && mode == kind.rawValue && (kind == .mixed || topics?.first == topic)
    }
    func savedAnswer(at index:Int) -> Int? {
        guard exercises.indices.contains(index),answers.indices.contains(index),exercises[index].choices.indices.contains(answers[index]) else { return nil }
        return answers[index]
    }
    var answeredCount:Int { exercises.indices.filter{savedAnswer(at:$0) != nil}.count }
    var correctCount:Int { exercises.indices.filter{savedAnswer(at:$0) == exercises[$0].answer}.count }
    var answeredTopics:Set<String> {
        Set(exercises.indices.compactMap { i in
            guard savedAnswer(at:i) != nil,let topics,topics.indices.contains(i),IndependentPractice.topics.contains(topics[i]) else { return nil }
            return topics[i]
        })
    }
}
struct PracticeHistorySummary {
    var answered=0
    var correct=0
    var topics:Set<String>=[]
    var accuracy:String { answered == 0 ? "—":String(format:"%.0f%%",Double(correct)/Double(answered)*100) }
}
@MainActor final class ReasoningModel:ObservableObject {
    typealias Requester=(AIProvider,String,DatabricksWorkspace,[TopicStat],PracticeMode) async throws -> [PracticeItem]
    @Published var consent=false { didSet { if !consent { cancelPending() } } }
    // Legacy AI observations remain archived on disk and never enter practice history statistics.
    @Published var observations:[ReasoningObservation]=[]
    @Published var archive:[PracticeSession]=[]
    @Published var exercises:[Quiz]=[]
    @Published var answers:[Int]=[]
    @Published var exerciseTopics:[String]=[]
    @Published var day=""
    @Published var practiceSetID=UUID()
    @Published private(set) var currentSessionID=UUID()
    @Published private(set) var currentCreatedAt:Date?
    @Published var busy=false
    @Published var message="Choose Mixed Practice or Topic Practice. AI receives only concepts and aggregate counts."
    @Published private(set) var provider:AIProvider = .databricks
    @Published private(set) var model=DatabricksConfig.model
    @Published private(set) var workspace=DatabricksConfig.workspace
    private var mode=""
    private struct Context:Equatable { let mode:PracticeMode;let topic:String? }
    private var activeContext:Context?
    private var requestID=UUID()
    private var task:Task<Void,Never>?
    private let url:URL
    private let requester:Requester
    private var historyAvailable=true
    struct History:Codable {
        var observations:[ReasoningObservation];var exercises:[Quiz];var answers:[Int];var day:String
        var archive:[PracticeSession]?;var exerciseTopics:[String]?;var mode:String?
        var currentSessionID:UUID?;var currentCreatedAt:Date?
    }
    init(storageURL:URL? = nil,requester:Requester? = nil) {
        url=storageURL ?? FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0].appendingPathComponent("CodeCoach/reasoning.json")
        self.requester=requester ?? { provider,model,workspace,stats,mode in
            guard let key=try Keychain.read(service:provider.credentialService(workspace:workspace)),!key.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty else {
                throw CoachError.message("No credential is saved for "+provider.rawValue+". Add it in Settings > AI service.")
            }
            return try await DatabricksClient(provider:provider,workspace:workspace).generatePractice(stats:stats,key:key,model:model,mode:mode)
        }
        if FileManager.default.fileExists(atPath:url.path) {
            do {
                let h=try JSONDecoder().decode(History.self,from:Data(contentsOf:url))
                observations=h.observations;exercises=h.exercises;answers=h.answers;day=h.day;archive=h.archive ?? []
                exerciseTopics=h.exerciseTopics ?? [];mode=h.mode ?? "Legacy practice"
                currentSessionID=h.currentSessionID ?? UUID();currentCreatedAt=h.currentCreatedAt
                if answers.count != exercises.count { answers=exercises.indices.map { i in h.answers.indices.contains(i) && exercises[i].choices.indices.contains(h.answers[i]) ? h.answers[i] : -1 } }
            } catch { historyAvailable=false;message="Existing practice history could not be read. It has not been overwritten: "+error.localizedDescription }
        }
    }
    func configure(provider:AIProvider,model:String,workspace:DatabricksWorkspace = DatabricksConfig.workspace) {
        guard self.provider != provider || self.model != model || self.workspace != workspace else { return }
        cancelRequest();self.provider=provider;self.model=model;self.workspace=workspace
        message="Selected AI service: "+provider.rawValue+". Enable AI practice requests when ready."
    }
    private func cancelPending() { requestID=UUID();task?.cancel();task=nil;busy=false }
    func cancelRequest() { consent=false;cancelPending() }
    @discardableResult func save() -> Bool {
        guard historyAvailable else { return false }
        do {
            try FileManager.default.createDirectory(at:url.deletingLastPathComponent(),withIntermediateDirectories:true)
            let h=History(observations:observations,exercises:exercises,answers:answers,day:day,archive:archive,exerciseTopics:exerciseTopics,mode:mode,currentSessionID:currentSessionID,currentCreatedAt:currentCreatedAt)
            try JSONEncoder().encode(h).write(to:url,options:.atomic)
            return true
        } catch { message="Could not save practice history: "+error.localizedDescription;return false }
    }
    var currentSession:PracticeSession? {
        guard !exercises.isEmpty else { return nil }
        return PracticeSession(id:currentSessionID,day:day,exercises:exercises,answers:answers,topics:exerciseTopics,mode:mode,createdAt:currentCreatedAt)
    }
    var historySessions:[PracticeSession] {
        let older=archive.filter{!$0.exercises.isEmpty}.sorted {
            if $0.day != $1.day { return $0.day > $1.day }
            return ($0.createdAt ?? .distantPast) > ($1.createdAt ?? .distantPast)
        }
        return (currentSession.map{[$0]} ?? [])+older
    }
    func historySummary(legacy:LegacyPracticeSummary = LegacyPracticeSummary()) -> PracticeHistorySummary {
        var total=PracticeHistorySummary(answered:legacy.answered,correct:legacy.correct,topics:Set(legacy.topics.filter{IndependentPractice.topics.contains($0)}))
        for session in historySessions { total.answered += session.answeredCount;total.correct += session.correctCount;total.topics.formUnion(session.answeredTopics) }
        return total
    }
    func activateContext(_ kind:PracticeMode,topic:String?) {
        let next=Context(mode:kind,topic:kind == .topic ? topic:nil)
        if activeContext == next && (currentSession == nil || currentSession!.matches(kind,topic:topic)) { return }
        cancelPending()
        if let current=currentSession,current.matches(kind,topic:topic) { activeContext=next;return }
        if let saved=historySessions.first(where:{$0.matches(kind,topic:topic)}) {
            if resumeSession(saved.id) { activeContext=next }
            return
        }
        let previous=(archive,exercises,answers,exerciseTopics,day,mode,currentSessionID,currentCreatedAt,activeContext)
        if let current=currentSession { archive.append(current) }
        exercises=[];answers=[];exerciseTopics=[];day="";mode=kind.rawValue
        currentSessionID=UUID();currentCreatedAt=nil;activeContext=next
        guard save() else {
            (archive,exercises,answers,exerciseTopics,day,mode,currentSessionID,currentCreatedAt,activeContext)=previous
            return
        }
        practiceSetID=UUID()
        message=kind == .mixed ? "Generate three questions from all concepts in Notes." : "Generate one question about the selected concept."
    }
    func resumeSession(_ id:UUID) -> Bool {
        guard !busy else { message="Wait for the current request to finish before resuming another set.";return false }
        if currentSession?.id == id { return currentSession?.isResumable == true }
        guard let index=archive.firstIndex(where:{$0.id == id}) else { return false }
        let selected=archive[index]
        guard selected.isResumable else { message="This earlier-format set is available for review only.";return false }
        let previous=(archive,exercises,answers,exerciseTopics,day,mode,currentSessionID,currentCreatedAt)
        archive.remove(at:index)
        if let current=currentSession { archive.append(current) }
        exercises=selected.exercises
        answers=selected.exercises.indices.map{selected.savedAnswer(at:$0) ?? -1}
        exerciseTopics=selected.topics ?? [];day=selected.day;mode=selected.mode ?? "Legacy practice"
        currentSessionID=selected.id;currentCreatedAt=selected.createdAt
        guard save() else {
            (archive,exercises,answers,exerciseTopics,day,mode,currentSessionID,currentCreatedAt)=previous
            return false
        }
        activeContext=Context(mode:PracticeMode(rawValue:mode)!,topic:mode == PracticeMode.topic.rawValue ? exerciseTopics.first:nil)
        practiceSetID=UUID();message="Resumed saved questions. Earlier answers were kept."
        return true
    }
    func topicPerformance(_ topic:String) -> (answered:Int,correct:Int) {
        var answered=0,correct=0
        let sessions=archive+[PracticeSession(day:day,exercises:exercises,answers:answers,topics:exerciseTopics,mode:mode)]
        for session in sessions {
            for i in session.exercises.indices {
                guard let topics=session.topics,topics.indices.contains(i),topics[i] == topic,session.answers.indices.contains(i),(0..<4).contains(session.answers[i]) else { continue }
                answered += 1
                if session.answers[i] == session.exercises[i].answer { correct += 1 }
            }
        }
        return (answered,correct)
    }
    func generate(stats:[TopicStat],mode:PracticeMode) {
        guard consent,!busy,historyAvailable else { return }
        do { _=try IndependentPractice.payload(stats);if mode == .topic && stats.count != 1 { throw CoachError.message("Choose one concept for Topic Practice.") } } catch { message=error.localizedDescription;return }
        let token=UUID();requestID=token
        let selectedProvider=provider,selectedModel=model,selectedWorkspace=workspace
        busy=true;message="Generating \(mode.questionCount) question(s) for \(mode.rawValue) with \(provider.rawValue)…"
        task=Task {
            defer { if requestID == token { busy=false } }
            do {
                let result=try await requester(selectedProvider,selectedModel,selectedWorkspace,stats,mode)
                let valid=try IndependentPractice.validate(result,allowedTopics:stats.map(\.topic),mode:mode)
                guard !Task.isCancelled,requestID == token,consent else { return }
                if let current=currentSession { archive.append(current) }
                exercises=valid.map(\.quiz);exerciseTopics=valid.map(\.topic);answers=Array(repeating:-1,count:valid.count)
                let formatter=DateFormatter();formatter.dateFormat="yyyy-MM-dd";day=formatter.string(from:Date())
                self.mode=mode.rawValue;activeContext=Context(mode:mode,topic:mode == .topic ? stats.first?.topic:nil)
                currentSessionID=UUID();currentCreatedAt=Date();practiceSetID=UUID();message="\(mode.questionCount) question(s) ready for \(mode.rawValue). Refresh at any time.";save()
            } catch { if !Task.isCancelled,requestID == token { message=error.localizedDescription } }
        }
    }
    func submit(index:Int,choice:Int) {
        guard exercises.indices.contains(index),answers.indices.contains(index),answers[index] < 0,(0..<4).contains(choice) else { return }
        answers[index]=choice;save()
    }
    func testConnection() {
        guard consent,!busy else { return }
        let token=UUID();requestID=token;let selectedProvider=provider,selectedModel=model,selectedWorkspace=workspace
        busy=true;message="Testing "+selectedProvider.rawValue+"…"
        task=Task {
            defer { if requestID == token { busy=false } }
            do {
                guard let key=try Keychain.read(service:selectedProvider.credentialService(workspace:selectedWorkspace)),!key.isEmpty else { throw CoachError.message("No credential is saved for "+selectedProvider.rawValue+". Add it in Settings > AI service.") }
                try await DatabricksClient(provider:selectedProvider,workspace:selectedWorkspace).testConnection(key:key,model:selectedModel)
                guard !Task.isCancelled,requestID == token,consent else { return }
                message=selectedProvider.rawValue+" connection and structured response test succeeded."
            } catch { if !Task.isCancelled,requestID == token { message=error.localizedDescription } }
        }
    }
    func clearLearning() {
        cancelRequest();observations=[];archive=[];exercises=[];answers=[];exerciseTopics=[];day="";mode="";activeContext=nil;currentCreatedAt=nil;currentSessionID=UUID();historyAvailable=true;practiceSetID=UUID()
        if save() { message="Learning history cleared. AI credentials were kept." }
    }
}

struct UnifiedPracticeView:View {
    @ObservedObject var app:AppModel
    @ObservedObject var model:ReasoningModel
    @State private var selections:[Int:Int]=[:]
    @State private var showingHistory=false
    var body:some View {
        VStack(alignment:.leading,spacing:16) {
            if showingHistory {
                PracticeHistoryView(app:app,model:model,onBack:{showingHistory=false},onResume:{ session in
                    if model.resumeSession(session.id) {
                        app.practiceMode=session.mode == "Mixed Practice" ? 0:1
                        if let topic=session.topics?.first,IndependentPractice.topics.contains(topic) { app.practiceTopic=topic }
                        showingHistory=false
                    }
                })
            } else {
                HStack {
                    Spacer()
                    Button { showingHistory=true } label: { Label("Practice History",systemImage:"clock.arrow.circlepath").font(.system(size:16,weight:.medium)) }.buttonStyle(.bordered)
                }
                CenteredTabs(titles:["Mixed Practice","Topic Practice"],selection:Binding(get:{app.practiceMode},set:{app.selectPracticeMode($0)}))
                if app.practiceMode == 0 {
                    Text("Three questions based on all recorded concepts in Notes.").font(.system(size:17))
                    if app.practiceStats.isEmpty {
                        Text("No recorded concepts yet. Choose Topic Practice to start without connecting a file.")
                        Button("Choose a topic") { app.selectPracticeMode(1) }
                    } else { Text(app.practiceStats.map(\.topic).joined(separator:" · ")).font(.callout) }
                } else {
                    Picker("Concept",selection:Binding(get:{app.practiceTopic},set:{app.selectPracticeTopic($0)})) {
                        ForEach(IndependentPractice.topics,id:\.self) { Text($0).tag($0) }
                    }.font(.system(size:16))
                }
                Text(app.practiceMode == 0 ? "Mixed Practice samples your recorded concepts. Refresh for three new questions. Source code and raw diagnostics are never sent." : "Topic Practice generates one question about your selected concept. Refresh for another question on that concept.").font(.callout)
                Text("Current AI service: "+app.provider.rawValue+" · "+app.model).font(.callout)
                if app.provider == .databricks { Text("Workspace: "+app.databricksWorkspace.host).font(.callout) }
                if app.workspaceChangesPending { Text("Apply workspace changes in Settings before making AI requests.").font(.callout).foregroundStyle(.orange) }
                AIRequestConsentToggle(model:model)
                WideDisclosure("Preview data sent to AI") {
                    Text((try? IndependentPractice.payload(app.practiceStats)) ?? "Select a practice concept.").font(.system(size:13,design:.monospaced)).textSelection(.enabled)
                }
                Button(generationTitle) {
                    model.generate(stats:app.practiceStats,mode:app.selectedPracticeMode)
                }.buttonStyle(.borderedProminent).disabled(!model.consent || model.busy || app.practiceStats.isEmpty || app.workspaceChangesPending)
                if model.busy { HStack { ProgressView();Button("Cancel request") { model.cancelRequest() } } }
                Text(model.message).font(.callout).textSelection(.enabled)
                Text("Completed: \(displayedSession?.answeredCount ?? 0)/\(displayedSession?.exercises.count ?? 0)")
                ForEach(displayedSession == nil ? 0..<0:model.exercises.indices,id:\.self) { i in
                    let q=model.exercises[i]
                    VStack(alignment:.leading,spacing:12) {
                        Text("Question \(i+1)").font(.system(size:19,weight:.semibold))
                        if model.exerciseTopics.indices.contains(i) { Text(model.exerciseTopics[i]).font(.callout).foregroundStyle(ComicReviewTheme.aiInk) }
                        Text(q.question).font(.system(size:17)).textSelection(.enabled)
                        ForEach(q.choices.indices,id:\.self) { choice in
                            Button { selections[i]=choice } label: {
                                HStack(alignment:.top) {
                                    Image(systemName:chosenAnswer(i) == choice ? "largecircle.fill.circle":"circle")
                                    Text(q.choices[choice]).frame(maxWidth:.infinity,alignment:.leading)
                                }.padding(10)
                            }.buttonStyle(.bordered).disabled(model.answers.indices.contains(i) && model.answers[i] >= 0)
                        }
                        if model.answers.indices.contains(i),model.answers[i] < 0 {
                            Button("Check my answer") { if let choice=selections[i] { model.submit(index:i,choice:choice) } }
                                .buttonStyle(.borderedProminent).disabled(selections[i] == nil)
                        } else if model.answers.indices.contains(i) {
                            Text(model.answers[i] == q.answer ? "Correct":"Review the explanation").font(.headline)
                            Text(q.explanation).textSelection(.enabled)
                        }
                    }.padding(16).frame(maxWidth:.infinity,alignment:.leading)
                        .background(ComicReviewTheme.ai.opacity(0.16),in:RoundedRectangle(cornerRadius:12))
                }
                Text("AI-generated exercises and answers may be incorrect. No code is executed.").font(.callout).foregroundStyle(.secondary)
            }
        }.font(.system(size:16))
            .onAppear { app.synchronizePracticeContext() }
    }
    private var displayedSession:PracticeSession? {
        guard let session=model.currentSession,session.matches(app.selectedPracticeMode,topic:app.practiceMode == 1 ? app.practiceTopic:nil) else { return nil }
        return session
    }
    private var generationTitle:String {
        if app.practiceMode == 0 { return displayedSession == nil ? "Generate three questions":"Refresh three questions" }
        return displayedSession == nil ? "Generate one question":"Refresh one question"
    }
    private func chosenAnswer(_ index:Int) -> Int? {
        model.currentSession?.savedAnswer(at:index) ?? selections[index]
    }
}


struct AIRequestConsentToggle:View {
    @ObservedObject var model:ReasoningModel
    var body:some View { Toggle("Allow AI practice requests",isOn:$model.consent) }
}

struct PracticeHistoryView:View {
    @ObservedObject var app:AppModel
    @ObservedObject var model:ReasoningModel
    let onBack:() -> Void
    let onResume:(PracticeSession) -> Void
    @State private var selectedSessionID:UUID?
    var body:some View {
        VStack(alignment:.leading,spacing:18) {
            Button(action:onBack) { Label("Back to Practice",systemImage:"chevron.left") }.buttonStyle(.bordered)
            Text("Practice History").font(.system(size:23,weight:.semibold))
            if let selectedSessionID,let session=model.historySessions.first(where:{$0.id == selectedSessionID}) {
                Button("Back to history") { self.selectedSessionID=nil }.buttonStyle(.bordered)
                sessionHeading(session)
                if session.isResumable && session.answeredCount < session.exercises.count {
                    Button("Continue this set") { onResume(session) }.buttonStyle(.borderedProminent).disabled(model.busy)
                }
                ForEach(session.exercises.indices,id:\.self) { index in
                    PracticeQuestionReview(quiz:session.exercises[index],number:index+1,topic:session.topics.flatMap{$0.indices.contains(index) ? $0[index]:nil},answer:session.savedAnswer(at:index),reviewOnly:!session.isResumable)
                }
                Text("Answers and explanations were generated by AI and may be incorrect.").font(.callout).foregroundStyle(.secondary)
            } else {
                summary
                Text("Saved question sets").font(.system(size:19,weight:.semibold))
                if model.historySessions.isEmpty { Text("No saved question sets yet. Generate a set in Practice to get started.").foregroundStyle(.secondary) }
                ForEach(model.historySessions) { session in
                    VStack(alignment:.leading,spacing:12) {
                        sessionHeading(session)
                        HStack {
                            Button("Review questions") { selectedSessionID=session.id }.buttonStyle(.bordered)
                            if session.isResumable && session.answeredCount < session.exercises.count {
                                Button("Continue this set") { onResume(session) }.buttonStyle(.bordered).disabled(model.busy)
                            }
                        }
                    }.padding(16).frame(maxWidth:.infinity,alignment:.leading)
                        .background(ComicReviewTheme.ai.opacity(0.13),in:RoundedRectangle(cornerRadius:12))
                }
            }
            if model.message.hasPrefix("Could not") { Text(model.message).font(.callout).foregroundStyle(.orange) }
        }.font(.system(size:16))
    }
    private var summary:some View {
        let totals=model.historySummary(legacy:app.legacyPractice)
        return VStack(alignment:.leading,spacing:12) {
            HStack(spacing:10) {
                metric(String(totals.answered),"Questions answered")
                metric(totals.accuracy,"Accuracy")
                metric(String(totals.topics.count),"Concepts practiced")
            }
            Text("Correct: \(totals.correct) / \(totals.answered) submitted answers. Unanswered questions are excluded.").font(.callout).foregroundStyle(.secondary)
            if app.legacyPractice.answered > 0 {
                Text("Includes \(app.legacyPractice.answered) answers from earlier diagnostic practice. That version did not save the original question text.").font(.callout).foregroundStyle(.secondary)
            }
            if model.historySessions.contains(where:{$0.answeredCount > 0 && ($0.topics?.isEmpty ?? true)}) {
                Text("Some older sets have no saved concept labels; their answers still count toward totals and accuracy.").font(.callout).foregroundStyle(.secondary)
            }
        }
    }
    private func metric(_ value:String,_ label:String) -> some View {
        VStack(alignment:.leading,spacing:7) {
            Text(value).font(.system(size:25,weight:.semibold,design:.rounded))
            Text(label).font(.system(size:14))
        }.frame(maxWidth:.infinity,minHeight:82,alignment:.leading).padding(12)
            .background(ComicReviewTheme.ai.opacity(0.13),in:RoundedRectangle(cornerRadius:12))
    }
    private func sessionHeading(_ session:PracticeSession) -> some View {
        VStack(alignment:.leading,spacing:7) {
            HStack {
                Text(session.mode?.isEmpty == false ? session.mode! : "Earlier practice").font(.system(size:18,weight:.semibold))
                Spacer()
                if session.id == model.currentSessionID { Text("Current set").font(.callout).foregroundStyle(ComicReviewTheme.aiInk) }
            }
            if let date=session.createdAt {
                Text(date,format:.dateTime.year().month().day().hour().minute()).font(.callout)
            } else { Text(session.day.isEmpty ? "Date not saved":session.day).font(.callout) }
            if let topics=session.topics,!topics.isEmpty { Text(Array(Set(topics)).sorted().joined(separator:" · ")).font(.callout) }
            Text("Completed: \(session.answeredCount)/\(session.exercises.count) · Correct: \(session.correctCount)/\(session.answeredCount)").font(.system(size:16))
            if !session.isResumable { Text("Earlier question format · review only").font(.callout).foregroundStyle(.secondary) }
        }
    }
}

struct PracticeQuestionReview:View {
    let quiz:Quiz
    let number:Int
    let topic:String?
    let answer:Int?
    var reviewOnly=false
    var body:some View {
        VStack(alignment:.leading,spacing:12) {
            Text("Question \(number)").font(.system(size:19,weight:.semibold))
            if let topic { Text(topic).font(.callout).foregroundStyle(ComicReviewTheme.aiInk) }
            Text(quiz.question).textSelection(.enabled)
            ForEach(quiz.choices.indices,id:\.self) { index in
                VStack(alignment:.leading,spacing:5) {
                    HStack(alignment:.top,spacing:8) {
                        Image(systemName:answer == index ? "checkmark.circle.fill":"circle")
                        Text(quiz.choices[index]).frame(maxWidth:.infinity,alignment:.leading).textSelection(.enabled)
                    }
                    if answer == index { Text("Your answer").font(.system(size:13,weight:.semibold)) }
                    if (answer != nil || reviewOnly) && quiz.answer == index { Text("Correct answer").font(.system(size:13,weight:.semibold)).foregroundStyle(ComicReviewTheme.aiInk) }
                }.padding(10).frame(maxWidth:.infinity,alignment:.leading)
                    .background(answer == index ? Color.gray.opacity(0.09):Color.clear,in:RoundedRectangle(cornerRadius:8))
            }
            if answer != nil || reviewOnly {
                Text(answer.map{$0 == quiz.answer ? "Correct":"Review the explanation"} ?? "Not answered · earlier-format review").font(.headline)
                Text("Explanation").font(.system(size:16,weight:.semibold))
                Text(quiz.explanation).textSelection(.enabled)
            } else { Text("Not answered. Continue this set to submit an answer and see the explanation.").font(.callout).foregroundStyle(.secondary) }
        }.padding(16).frame(maxWidth:.infinity,alignment:.leading)
            .background(Color.gray.opacity(0.04),in:RoundedRectangle(cornerRadius:12))
    }
}
