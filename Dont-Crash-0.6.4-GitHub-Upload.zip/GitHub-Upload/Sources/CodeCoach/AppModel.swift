import AppKit
import SwiftUI
#if SWIFT_PACKAGE
import CodeCoachCore
#endif

@MainActor final class AppModel:ObservableObject {
    let reasoning:ReasoningModel
    @Published var capturedSource:EditorCode?
    @Published var running=false
    @Published var busy=false
    @Published var status="Choose a Java source file or connect an editor."
    @Published var lastCleanCompilerFingerprint:String?
    @Published var compilerStatus="No compiler check completed for the current source."
    @Published var issue:String?
    @Published var editorName="Waiting for source connection"
    @Published var currentFile=""
    @Published var connectionHint=""
    @Published var permissionGranted=EditorReader.trusted
    @Published var records:[ErrorRecord]=[]
    @Published var stats:[TopicStat]=[]
    @Published var notesStats:[TopicStat]=[]
    @Published var legacyPractice=LegacyPracticeSummary()
    @Published var selectedFile:URL?
    @Published var practiceMode=0
    @Published var practiceTopic="Types and conversions"
    @Published var keyPresent=false
    @Published private(set) var databricksWorkspace:DatabricksWorkspace
    @Published var workspaceInput:String
    @Published var provider:AIProvider { didSet {
        defaults.set(provider.rawValue,forKey:"selectedAIProvider")
        model=defaults.string(forKey:provider.rawValue+"Model") ?? provider.defaultModel
        reasoning.configure(provider:provider,model:model,workspace:databricksWorkspace);refreshCredentialPresence()
    } }
    @Published var model:String { didSet {
        defaults.set(model,forKey:provider.rawValue+"Model")
        reasoning.configure(provider:provider,model:model,workspace:databricksWorkspace)
    } }
    @Published var javac:String { didSet { defaults.set(javac,forKey:"javac");if running { pause() } } }
    private let defaults:UserDefaults
    private var store:ErrorStore?
    private var watch:Task<Void,Never>?
    private var cancel=CancellationFlag()
    private var generation=UUID()
    private var editorID=""
    var projectID:String { "live:"+editorID }
    var activeCount:Int { LearningSelection.problems(records,resolved:false).count }
    var historyCount:Int { LearningSelection.problems(records,resolved:true).count }
    var compilerPassedForCurrentSource:Bool {
        guard !currentFile.isEmpty,!busy,let source=capturedSource else { return false }
        return lastCleanCompilerFingerprint == Diagnostic.digest(source.identity+"|"+source.text)
    }
    var showEmptyCompilerStatistics:Bool { stats.isEmpty && compilerPassedForCurrentSource }
    func practiceStat(_ topic:String) -> TopicStat {
        let old=notesStats.first{$0.topic == topic}
        let current=reasoning.topicPerformance(topic)
        return TopicStat(topic:topic,occurrences:old?.occurrences ?? 0,answered:(old?.answered ?? 0)+current.answered,correct:(old?.correct ?? 0)+current.correct)
    }
    var practiceStats:[TopicStat] {
        practiceMode == 0 ? notesStats.map{practiceStat($0.topic)} : [practiceStat(practiceTopic)]
    }
    func selectPracticeTopic(_ topic:String) {
        guard IndependentPractice.topics.contains(topic) else { return }
        practiceTopic=topic;practiceMode=1;synchronizePracticeContext()
    }
    var selectedPracticeMode:PracticeMode { practiceMode == 0 ? .mixed:.topic }
    func selectPracticeMode(_ index:Int) { practiceMode=index == 0 ? 0:1;synchronizePracticeContext() }
    func synchronizePracticeContext() { reasoning.activateContext(selectedPracticeMode,topic:practiceMode == 1 ? practiceTopic:nil) }
    init(preview:Bool = false,reasoningModel:ReasoningModel? = nil,preferences:UserDefaults = .standard) {
        defaults=preferences
        let selected=AIProvider(rawValue:preferences.string(forKey:"selectedAIProvider") ?? "Databricks") ?? .databricks
        let workspace=(try? DatabricksWorkspace(preferences.string(forKey:"databricksWorkspace") ?? DatabricksConfig.host)) ?? DatabricksConfig.workspace
        databricksWorkspace=workspace;workspaceInput=workspace.baseURL
        provider=selected
        model=preferences.string(forKey:selected.rawValue+"Model") ?? selected.defaultModel
        javac=preview ? "" : (JavaAnalyzer.findJavac() ?? preferences.string(forKey:"javac") ?? "")
        reasoning=reasoningModel ?? (preview ? ReasoningModel(storageURL:FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("reasoning.json")) : ReasoningModel())
        reasoning.configure(provider:provider,model:model,workspace:databricksWorkspace)
        guard !preview else { return }
        do {
            let dir=try FileManager.default.url(for:.applicationSupportDirectory,in:.userDomainMask,appropriateFor:nil,create:true).appendingPathComponent("CodeCoach",isDirectory:true)
            try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true,attributes:[.posixPermissions:0o700])
            store=try ErrorStore(url:dir.appendingPathComponent("learning.sqlite"));try reload()
        } catch { issue=error.localizedDescription }
        refreshCredentialPresence()
    }
    var workspaceChangesPending:Bool {
        provider == .databricks && (try? DatabricksWorkspace(workspaceInput)) != databricksWorkspace
    }
    func applyWorkspace() {
        do {
            let next=try DatabricksWorkspace(workspaceInput)
            workspaceInput=next.baseURL
            guard next != databricksWorkspace else { issue=nil;return }
            databricksWorkspace=next;defaults.set(next.baseURL,forKey:"databricksWorkspace")
            reasoning.configure(provider:provider,model:model,workspace:next)
            refreshCredentialPresence();issue=nil
            reasoning.message="Workspace applied: "+next.host+". Credentials are stored separately for each workspace."
        } catch { issue=error.localizedDescription }
    }
    func refreshCredentialPresence() {
        do { keyPresent=try Keychain.contains(service:provider.credentialService(workspace:databricksWorkspace)) }
        catch { keyPresent=false }
    }
    func requestPermission() {
        EditorReader.requestPermission()
        permissionGranted=EditorReader.trusted
        status="Allow Don't Crash in System Settings > Privacy & Security > Accessibility, then click Start."
    }
    func chooseSourceFile() {
        let panel=NSOpenPanel(); panel.canChooseDirectories=false; panel.allowsMultipleSelection=false
        panel.message="Select a saved Java source file. Your code stays on this Mac."
        panel.allowedFileTypes=["java"]
        if panel.runModal() == .OK, let url=panel.url, EditorReader.language(url.lastPathComponent) == "java" {
            disconnect(); selectedFile=url; connectionHint="File selected. Click Start to check saved content."; currentFile=url.lastPathComponent; start()
            let token=generation
            Task {
                let result=await Task.detached(priority:.utility) { EditorReader.read(file:url) }.value
                guard generation == token,running,selectedFile == url else { return }
                if case .code(let source)=result { receiveSource(source) }
                else if case .unavailable(let reason)=result { issue=reason }
            }
        }
    }
    func useEditor() { disconnect(); selectedFile=nil; start() }
    func discoverJava() { javac=JavaAnalyzer.findJavac() ?? ""; if javac.isEmpty { issue="No installed JDK found. Install a JDK, then click Detect again." } }
    func chooseJavac() {
        let picker=NSOpenPanel(); picker.canChooseDirectories=false; picker.canChooseFiles=true; picker.message="Select the JDK's Contents/Home/bin/javac, not the system launcher."
        if picker.runModal() == .OK, let url=picker.url { javac=url.path }
    }
    func start() {
        permissionGranted=EditorReader.trusted
        guard selectedFile != nil || permissionGranted else { requestPermission(); return }
        guard store != nil else { issue="Learning records are unavailable. Reopen the app."; return }
        if let discovered=JavaAnalyzer.findJavac() { javac=discovered }

        pause(); lastCleanCompilerFingerprint=nil; running=true; issue=nil; status="Switch to a Java editor and click its code area, or use the selected file."
        let token=UUID(); generation=token; let flag=CancellationFlag(); cancel=flag; let compiler=javac
        watch=Task { [weak self] in
            var candidate=""; var lastChecked=""
            while !Task.isCancelled {
                guard let self, self.generation == token, self.running else { return }
                let target=EditorReader.foregroundTarget()
                let file=self.selectedFile
                let reading=await Task.detached(priority:.utility) { file.map { EditorReader.read(file:$0) } ?? EditorReader.read(target:target) }.value
                guard self.generation == token, self.running, !Task.isCancelled else { return }
                switch reading {
                case .ownApplication: break
                case .unavailable(let hint):
                    self.lastCleanCompilerFingerprint=nil
                    self.connectionHint=hint; self.status="Waiting for readable Java source"; self.editorName="Disconnected"; self.currentFile=""
                    candidate=""; lastChecked=""
                case .code(let source):
                    self.receiveSource(source)
                    if self.editorID != source.identity {

                        self.editorID=source.identity
                        self.lastCleanCompilerFingerprint=nil
                        self.compilerStatus="No compiler check completed for the current source."
                        do { try self.reload() } catch { self.issue=error.localizedDescription }
                    }
                    let fingerprint=Diagnostic.digest(source.identity+"|"+source.text)
                    self.editorName=source.application; self.currentFile=source.filename
                    self.connectionHint=file == nil ? "Reading editor source, including unsaved edits." : "Checking the selected file on disk. Save edits in your editor."
                    if fingerprint != lastChecked {
                        if candidate == fingerprint {
                            if EditorReader.language(source.filename) != "java" || compiler.isEmpty {
                                lastChecked=fingerprint; self.compilerStatus="Compiler check unavailable for this source."; self.status="Select a Java source file and install a JDK to check it."
                                try? await Task.sleep(nanoseconds:700_000_000)
                                continue
                            }
                            self.busy=true; self.status="Checking source…"; self.compilerStatus="Running local javac single-file check…"
                            do {
                                let results=try await Task.detached(priority:.utility) { try LiveSource.analyze(text:source.text,filename:source.filename,javac:compiler,cancellation:flag) }.value
                                guard self.generation == token, self.running, !Task.isCancelled else { return }
                                self.busy=false
                                // Never publish a result for text that changed during compilation.
                                let latestTarget=EditorReader.foregroundTarget()
                                let latestReading=await Task.detached(priority:.utility) { file.map { EditorReader.read(file:$0) } ?? EditorReader.read(target:latestTarget) }.value
                                guard self.generation == token, self.running, !Task.isCancelled else { return }
                                guard case .code(let latest)=latestReading, latest.identity == source.identity, latest.text == source.text else { candidate=""; continue }
                                if self.editorID != source.identity {

                                    self.editorID=source.identity
                                }
                                try self.store?.reconcile(project:self.projectID,diagnostics:results); try self.reload()
                                lastChecked=fingerprint
                                self.compilerStatus=results.isEmpty ? "This single-file compilation reported no errors. Logic and runtime behavior have not been verified." : "Local javac reported \(results.count) compilation errors in this single-file check. Logic and runtime behavior have not been verified."
                                self.lastCleanCompilerFingerprint=results.isEmpty ? fingerprint : nil
                                self.status=self.compilerStatus
                            } catch {
                                guard self.generation == token, !Task.isCancelled else { return }
                                self.busy=false
                                self.lastCleanCompilerFingerprint=nil
                                self.compilerStatus="Compiler check unavailable. No conclusion about code correctness."
                                self.issue="Compiler check unavailable: "+error.localizedDescription+""
                                lastChecked=fingerprint
                            }
                        }
                        candidate=fingerprint
                    }
                }
                try? await Task.sleep(nanoseconds:700_000_000)
            }
        }
    }
    func receiveSource(_ source:EditorCode) { capturedSource=source }
    func pause() { generation=UUID(); cancel.cancel(); watch?.cancel(); watch=nil; running=false; busy=false; status="Paused · no source reading" }
    func reload() throws {
        records=try store?.records(project:projectID) ?? []
        stats=try store?.stats(project:projectID) ?? []
        notesStats=(try store?.allStats() ?? []).filter{IndependentPractice.topics.contains($0.topic)}
        legacyPractice=try store?.legacyPracticeSummary() ?? LegacyPracticeSummary()
    }
    func saveKey(_ key:String) {
        let value=key.trimmingCharacters(in:.whitespacesAndNewlines)
        do {
            guard !workspaceChangesPending else { throw CoachError.message("Apply workspace changes before saving its credential.") }
            guard !value.isEmpty,!value.contains("\n"),!value.contains("\r") else { throw CoachError.message("Enter a valid single-line credential for "+provider.rawValue+".") }
            try Keychain.save(value,service:provider.credentialService(workspace:databricksWorkspace));keyPresent=true;issue=nil
            reasoning.message=provider.rawValue+" credential saved. Enable AI requests and test the connection."
        } catch { issue=error.localizedDescription }
    }
    func deleteKey() {
        guard !workspaceChangesPending else { issue="Apply workspace changes before managing its credential.";return }
        reasoning.cancelRequest()
        do { try Keychain.delete(service:provider.credentialService(workspace:databricksWorkspace));keyPresent=false } catch { issue=error.localizedDescription }
    }
    func erase() {
        pause();reasoning.cancelRequest()
        do { try store?.erase();reasoning.clearLearning();try reload();issue=nil;status="Learning records cleared." }
        catch { issue=error.localizedDescription }
    }
    func disconnect() {
        pause();capturedSource=nil;selectedFile=nil;editorID="";records=[];stats=[]
        editorName="Waiting for source connection";currentFile="";lastCleanCompilerFingerprint=nil
        compilerStatus="No compiler check completed for the current source."
    }
}
