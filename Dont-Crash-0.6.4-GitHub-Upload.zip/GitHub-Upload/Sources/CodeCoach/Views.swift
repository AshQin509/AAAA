import SwiftUI
import AppKit
#if SWIFT_PACKAGE
import CodeCoachCore
#endif

let coachAccent=Color(red:0.12,green:0.30,blue:0.70)
struct ComicStartButtonStyle:ButtonStyle {
    let running:Bool
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration:Configuration) -> some View {
        let pressed=configuration.isPressed
        configuration.label
            .font(.system(size:17,weight:.semibold,design:.rounded))
            .foregroundStyle(ComicReviewTheme.ink)
            .padding(.horizontal,14).padding(.vertical,8)
            .background(RoundedRectangle(cornerRadius:13).fill(running ? Color(red:1,green:0.78,blue:0.55):ComicReviewTheme.compiler))
            .overlay(RoundedRectangle(cornerRadius:13).stroke(ComicReviewTheme.ink,lineWidth:2.5))
            .background(RoundedRectangle(cornerRadius:13).fill(ComicReviewTheme.ink).offset(x:pressed ? 1:4,y:pressed ? 1:4))
            .offset(x:pressed ? 3:0,y:pressed ? 3:0)
            .opacity(enabled ? 1:0.5)
            .padding(.trailing,5).padding(.bottom,5)
            .contentShape(Rectangle())
            .animation(.easeOut(duration:0.1),value:pressed)
    }
}

struct CoachPanel:View {
    @ObservedObject var model:AppModel
    @ObservedObject private var reasoning:ReasoningModel
    let collapse:() -> Void
    var companion:() -> Void = {}
    @State private var tab=0
    @State private var showHistory=false
    @State private var key=""
    @State private var confirmErase=false
    init(model:AppModel,collapse:@escaping () -> Void,companion:@escaping () -> Void = {},initialTab:Int = 0) {
        self.model=model;_reasoning=ObservedObject(wrappedValue:model.reasoning);self.collapse=collapse;self.companion=companion;_tab=State(initialValue:initialTab)
    }
    var body:some View {
        VStack(spacing:0) {
            PanelTitlebar(collapse:collapse).frame(height:76)
            HStack { Spacer();Button("Show companion",systemImage:"arrow.down.right.and.arrow.up.left") { companion() }.buttonStyle(.borderless) }.padding(.horizontal,20).padding(.bottom,8)
            HStack {
                Circle().fill(model.running ? coachAccent:.gray).frame(width:6,height:6)
                Text(model.running ? "Checking active":"Checking paused").font(.system(size:14))
                Spacer()
                Button { model.running ? model.pause():model.start() } label: {
                    HStack(spacing:9) {
                        Image(systemName:model.running ? "pause.fill":"play.fill")
                            .font(.system(size:13,weight:.bold)).frame(width:26,height:26)
                            .background(Color.white.opacity(0.8),in:Circle())
                            .overlay(Circle().stroke(ComicReviewTheme.ink,lineWidth:1.5))
                        Text(model.running ? "Pause":"Start")
                    }
                }.buttonStyle(ComicStartButtonStyle(running:model.running))
            }.padding(.horizontal,20).padding(.bottom,14)
            CenteredTabs(titles:["Check","Notes","Practice","Settings"],selection:$tab).padding(.horizontal,20).padding(.bottom,16)
            Divider()
            ScrollView {
                VStack(alignment:.leading,spacing:18) {
                    if let issue=model.issue {
                        VStack(alignment:.leading,spacing:8) {
                            Label("Attention",systemImage:"exclamationmark.triangle").foregroundStyle(.orange)
                            Text(issue).font(.callout).textSelection(.enabled)
                            Button("Dismiss") { model.issue=nil }
                        }.padding(12).background(.orange.opacity(0.08),in:RoundedRectangle(cornerRadius:12))
                    }
                    switch tab {
                    case 0: check
                    case 1: notes
                    case 2: UnifiedPracticeView(app:model,model:reasoning).id(reasoning.practiceSetID)
                    default: settings
                    }
                }.padding(20).frame(maxWidth:.infinity,alignment:.leading)
            }
            Divider()
            HStack(spacing:8) {
                if model.busy { ProgressView().controlSize(.mini) }
                Text(model.status).font(.system(size:13)).foregroundStyle(.secondary).lineLimit(2);Spacer()
            }.padding(12)
        }.frame(width:620,height:720).background(Color.white).preferredColorScheme(.light).font(.system(size:15)).tint(coachAccent)
            .onReceive(Timer.publish(every:1,on:.main,in:.common).autoconnect()) { _ in model.permissionGranted=EditorReader.trusted }
            .confirmationDialog("Clear all learning records, including archived AI observations?",isPresented:$confirmErase) {
                Button("Clear all learning records",role:.destructive) { model.erase() }
            }
    }
    private var check:some View {
        VStack(alignment:.leading,spacing:16) {
            VStack(alignment:.leading,spacing:10) {
                Text(model.currentFile.isEmpty ? "Source connection":"Source connection · "+model.currentFile).font(.system(size:16,weight:.medium))
                Label(model.editorName,systemImage:"macwindow").font(.system(size:14))
                HStack { Button("Choose Java file…") { model.chooseSourceFile() };Button("Use editor") { model.useEditor() } }
            }
            Divider().padding(.vertical,4)
            Text("Check results").font(.system(size:20,weight:.medium))
            Text(model.compilerStatus).font(.system(size:17)).textSelection(.enabled)
            diagnostics
            Text("Checks run locally with javac. Your code stays on this Mac; no AI code review is performed.").font(.callout).foregroundStyle(.secondary)
            Button("View recorded concepts in Notes") { tab=1 }
        }
    }
    private var diagnostics:some View {
        VStack(alignment:.leading,spacing:12) {
            CenteredTabs(titles:["Last reported","No longer reported"],selection:Binding(get:{showHistory ? 1:0},set:{showHistory=$0 == 1}))
            if !model.permissionGranted && model.selectedFile == nil {
                Button("Allow editor access…") { model.requestPermission() }
            }
            let records=LearningSelection.problems(model.records,resolved:showHistory)
            if records.isEmpty {
                if model.showEmptyCompilerStatistics { Text("No compiler diagnostic statistics for this source.") }
                else { Text("No matching saved diagnostics.") }
            }
            ForEach(records) { record in
                VStack(alignment:.leading,spacing:8) {
                    Text(record.diagnostic.category).font(.headline)
                    Text(record.diagnostic.file+" · line "+String(record.diagnostic.line)).font(.system(size:14,design:.monospaced))
                    if let line=record.diagnostic.sourceLine { Text(line).font(.system(size:14,design:.monospaced)).textSelection(.enabled) }
                    Text(record.diagnostic.code+": "+record.diagnostic.message).font(.callout).textSelection(.enabled)
                    Text(record.active ? "Reported by local javac":"No longer reported in the latest completed check").font(.callout).foregroundStyle(.secondary)
                    Button("Practice this concept") { model.selectPracticeTopic(record.diagnostic.category);tab=2 }
                }.padding(12).frame(maxWidth:.infinity,alignment:.leading).background(.yellow.opacity(0.12),in:RoundedRectangle(cornerRadius:10))
            }
            Text("These single-file results may be stale after edits or disconnection. Missing project dependencies can cause misleading diagnostics. Verify in your IDE.").font(.callout).foregroundStyle(.secondary)
        }
    }
    private var notes:some View {
        VStack(alignment:.leading,spacing:16) {
            Text("Notes").font(.system(size:22,weight:.semibold))
            Text("Concepts recorded from local Java compiler diagnostics across your source files. These counts describe events, not ability or mastery.").font(.system(size:16))
            if model.notesStats.isEmpty {
                Text("No diagnostic concepts recorded yet.").foregroundStyle(.secondary)
                Button("Start with a topic instead") { model.selectPracticeMode(1);tab=2 }
            }
            ForEach(model.notesStats,id:\.topic) { stat in
                let performance=model.practiceStat(stat.topic)
                VStack(alignment:.leading,spacing:10) {
                    Text(stat.topic).font(.system(size:18,weight:.semibold))
                    Text("Compiler occurrences: \(stat.occurrences)").font(.system(size:16))
                    Text("Practice answers: \(performance.answered) · Correct: \(performance.correct)").font(.callout)
                    Button("Practice this concept") { model.selectPracticeTopic(stat.topic);tab=2 }
                }.padding(16).frame(maxWidth:.infinity,alignment:.leading).background(ComicReviewTheme.ai.opacity(0.16),in:RoundedRectangle(cornerRadius:12))
            }
            Text("Earlier AI suggestions remain archived locally and are excluded from these notes and new question requests.").font(.callout).foregroundStyle(.secondary)
        }
    }
    private var settings:some View {
        VStack(alignment:.leading,spacing:16) {
            Text("AI service").font(.system(size:22,weight:.semibold))
            Text("One service and model for both Mixed Practice and Topic Practice.").font(.system(size:16))
            Picker("Current service",selection:$model.provider) {
                ForEach(AIProvider.allCases,id:\.self) { Text($0.rawValue).tag($0) }
            }.onChange(of:model.provider) { _ in key="" }
            if model.provider == .databricks {
                VStack(alignment:.leading,spacing:8) {
                    Text("Databricks Workspace").font(.system(size:16,weight:.medium))
                    TextField("https://your-workspace.cloud.databricks.com",text:$model.workspaceInput).textFieldStyle(.roundedBorder)
                        .onChange(of:model.workspaceInput) { _ in key="" }
                    Button("Apply workspace") { model.applyWorkspace();key="" }
                    Text("Applied: "+model.databricksWorkspace.baseURL).font(.callout).textSelection(.enabled)
                    Text("Paste your workspace URL and apply it before saving its credential. Existing workspace credentials stay separate.").font(.callout)
                }
            }
            TextField("Model ID",text:$model.model).textFieldStyle(.roundedBorder)
            SecureField("Credential for "+model.provider.rawValue,text:$key).textFieldStyle(.roundedBorder)
            HStack {
                Button("Save credential") { model.saveKey(key);key="" }.disabled(key.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || model.workspaceChangesPending)
                Text(model.keyPresent ? "Saved":"Not confirmed").font(.callout).foregroundStyle(.secondary)
                Spacer()
                Button("Delete credential",role:.destructive) { model.deleteKey();key="" }.disabled(model.workspaceChangesPending)
            }
            Text("Each service keeps its own credential in macOS Keychain. Changing the service, model, or workspace cancels pending requests and resets consent.").font(.callout)
            AIRequestConsentToggle(model:reasoning)
            Button("Test selected service") { reasoning.testConnection() }.disabled(!reasoning.consent || reasoning.busy || model.workspaceChangesPending)
            if reasoning.busy { Button("Cancel request") { reasoning.cancelRequest() } }
            Text(reasoning.message).font(.callout).textSelection(.enabled)
            Text("Only concept names and aggregate counts are sent for practice. Source code, raw diagnostics, filenames, file paths and earlier AI observations are excluded. Requests may incur provider charges.").font(.callout).foregroundStyle(.secondary)
            Divider()
            Text("Local checking").font(.system(size:19,weight:.semibold))
            Button("Choose Java file…") { model.chooseSourceFile() }
            Button("Use editor") { model.useEditor() }
            Button("Disconnect source") { model.disconnect() }
            Button("Check / request Accessibility permission…") { model.requestPermission() }
            WideDisclosure("Java compiler settings") {
                VStack(alignment:.leading,spacing:10) {
                    Button("Detect / refresh JDK") { model.discoverJava() }
                    Text(model.javac.isEmpty ? "No JDK detected":"Detected: "+model.javac).font(.callout).textSelection(.enabled)
                    Button("Select installed javac…") { model.chooseJavac() }
                    Link("Install a Java compiler (Temurin JDK)",destination:URL(string:"https://adoptium.net/temurin/releases/")!)
                    Text("Single-file checks do not resolve Maven/Gradle or project dependencies.").font(.callout)
                }
            }
            Divider()
            Text("Local learning records").font(.system(size:19,weight:.semibold))
            Button("Clear all learning records…",role:.destructive) { confirmErase=true }
            Text("Includes compiler records, exercises and archived AI observations. Saved credentials are kept.").font(.callout).foregroundStyle(.secondary)
        }
    }
}

struct CompactCoach: View {
    @ObservedObject var model:AppModel
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var pulse=false
    var body:some View {
        Image(nsImage:CompanionArtwork.image)
            .resizable().scaledToFit().padding(4).frame(width:88,height:88)
            .opacity(pulse ? 0.55 : 1)
            .onChange(of:model.activeCount) { value in
                guard value > 0,!reduceMotion else { return }
                withAnimation(.easeInOut(duration:0.25).repeatCount(4,autoreverses:true)) { pulse=true }
                DispatchQueue.main.asyncAfter(deadline:.now()+1.2) { pulse=false }
            }
            .accessibilityLabel("Don't Crash assistant. Click to open; right-click for Quit.")
    }
}
