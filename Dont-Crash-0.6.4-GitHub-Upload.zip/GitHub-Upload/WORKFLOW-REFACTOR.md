# Unified learning workflow — 0.6.4

## Implemented

- Check contains source controls and local Java diagnostics only. Accessibility/file capture cannot initiate AI requests. Direct AI source analysis and diagnostic-explanation request methods have been removed.
- Notes aggregates fixed compiler categories across sources, retaining occurrence semantics and prior SQLite answer statistics. Historical AI observations are excluded from Notes and practice selection.
- Mixed and Topic Practice share one validated, mode-aware API (Mixed: three questions from all Notes concepts; Topic: one question on the selected concept), one topic catalog and one answer/session history. Topic Practice is available with no source or error history. Successful refreshes archive previous sets; failed/invalid refreshes leave current questions and answers intact. Provider/model changes cancel pending work and revoke consent.
- Settings has one provider/model/key/test area for Databricks, OpenAI and DeepSeek. Existing Keychain identifiers and provider-specific saved models are preserved. Databricks workspace endpoint is unchanged. Current selection is persisted.
- Practice History replaces the Progress tab. It reviews saved current and archived sets, aggregate submitted-answer statistics and known concepts. Legacy exercises without topic metadata are retained without inventing topic performance.

## Request boundary

The only practice input is an array of whitelisted `TopicStat` values with `topic`, `occurrences`, `answered`, and `correct`. Unknown topics, duplicate topics and invalid count combinations are rejected. Code, diagnostics, file paths, filenames, project identities, raw historical observations and previous question text are not part of the request. The output must contain exactly three validated questions for Mixed Practice, or one for Topic Practice, with topics from the requested set. Mixed requests include all Notes concepts and require coverage of up to three different concepts. This checks shape and topic scope, not answer correctness.

## Storage and rollback

The existing Application Support location, SQLite tables and reasoning.json identity are retained. Legacy JSON observations and practice sessions still decode; new optional topic/mode fields do not invalidate old records. Earlier single-question attempts remain in SQLite. Local source branches are `archive/pre-simplification` and `refactor/learning-workflow`; no remote push was performed. The installer backs up original files and the old app before applying updates and preserves any existing repository metadata.

## Verification

- Native app compiled for Apple Silicon; ad-hoc signature verified.
- SwiftPM XCTest: 30 tests, 26 passed, 4 JDK-dependent tests skipped, no failures. Current tests cover compiler/storage behavior, three-provider practice request routing and safe payloads, provider error handling, three-question validation, connection probes and global Notes statistics. Obsolete tests of removed AI explanation/single-question endpoints were replaced by unified-generator tests.
- Native mock workflow checks: legacy JSON/answers preserved, no-source Topic Practice, exclusion of archived AI observations, repeated same-day refresh, idempotent answers, failure preservation, provider/model routing, provider-specific model persistence, cancellation and stale-response rejection.
- Native synthetic previews of all five pages were rendered and inspected. Original compiler/editor and window helper code remains in place.
- No live AI request, billing operation, key read or secret inspection was performed. Real service availability, model permissions and output quality still require the in-app Test selected service action and a real generation request. No claim of full project build integration or all-editor compatibility is made.

## 0.6.1 — simplified Check layout

Removed the Java Compiler card and its dedicated disclosure. Check results, current/history filters and diagnostic details now appear directly in the page. The top Start/Pause control uses a rounded comic button with a dark outline, offset shadow, contrasting icon and pressed state. No monitoring, AI request or storage logic changed. The native layout checks passed and the updated Check page was visually inspected.

## 0.6.2 — editable Databricks workspace and shared consent

Settings now accepts an editable Databricks Workspace URL with an explicit Apply workspace action. Host-only or HTTPS workspace URLs from AWS, Azure and GCP are normalized to the HTTPS origin. Workspace changes are persisted, generation and connection tests route to the applied workspace, and credentials use a host-specific Keychain identifier. The original workspace retains its earlier identifier. Draft changes cannot trigger credential saves, deletes or AI requests until applied. Applying a changed workspace cancels pending requests and revokes consent.

Practice, Progress and Settings render one shared consent control, labeled Allow AI practice requests, bound to one state. No independent authorization state was introduced.

Verification: 33 XCTest cases executed (29 passed, 4 JDK-dependent skips, zero failures). Additional native workflow checks cover workspace persistence, unapplied-edit credential guards, request routing and cancellation. No live API call or key inspection was made. Progress's content has otherwise been left unchanged pending a product decision.

## 0.6.3 — Practice History replaces Progress

Removed the independent Progress tab. A Practice History button above the Mixed / Topic selector opens a dedicated in-Practice history view with aggregate answered count, accuracy and known practiced concepts. Accuracy excludes unanswered questions. Current and archived question sets show date/time when available, mode, concepts, completion and correct counts. Answer review restores the submitted option and explanation; unanswered questions do not reveal an answer before submission. Unfinished sets can be resumed without losing earlier answers or counting a set twice.

Current set IDs and generation timestamps are now persisted as optional backward-compatible metadata. Legacy JSON without those fields remains readable; existing valid answers are retained even if an older answer array is incomplete. Earlier SQLite-only attempts contribute aggregate counts; the UI explains that the original question text was not saved in that version. Earlier AI observations remain in the legacy JSON field but have no Progress UI and are excluded from all practice-history metrics.

Verification: 34 XCTest cases (30 passed, 4 JDK-dependent skips, no failures). Native history checks covered zero-answer accuracy, cumulative totals, legacy SQLite counts, topic counts, stable IDs/timestamps, resume without duplication, saved answer restoration, rollback on failed resume saves and older JSON compatibility. History overview, answer review and the navigation entry were rendered with synthetic data and visually inspected. No live API request was made.

## 0.6.4 — separate Mixed and Topic Practice

Mixed sends all Notes concepts and aggregate counts, requests three questions and validates coverage across up to three concepts. Topic sends only the selected concept and requests one question. All three providers use the same explicit mode and count validation. Button labels, completion counts and descriptions reflect the selected mode.

Switching mode or topic restores its latest compatible saved set and answers, or shows an empty generation state. Pending requests are cancelled on context changes. Earlier three-question Topic sets remain in History as review-only records; they cannot reappear as current one-question Topic practice.

Verification: 36 XCTest cases (32 passed, four JDK-dependent skips, zero failures). Native mock checks passed for all-Notes input (six concepts), Topic one-question input, mode/topic isolation, answer preservation, restart restoration, history totals, cancellation and legacy set compatibility. Existing refresh/history checks passed. Mixed and Topic native previews were visually inspected. No live AI request or credential inspection was performed.
