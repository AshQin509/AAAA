import Foundation
import SwiftUI

@main struct PracticeHistoryTests {
    @MainActor static func main() async throws {
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:dir) }
        let url=dir.appendingPathComponent("reasoning.json")
        var request=0
        let model=ReasoningModel(storageURL:url,requester:{ _,_,_,stats,mode in
            request += 1
            return (0..<3).map { i in PracticeItem(topic:stats[i % stats.count].topic,quiz:Quiz(question:"Set \(request), question \(i)",choices:["A","B","C","D"],answer:i,explanation:"Explanation")) }
        })
        precondition(model.historySessions.isEmpty && model.historySummary().accuracy == "—")
        let stats=[TopicStat(topic:"Types and conversions",occurrences:0,answered:0,correct:0),TopicStat(topic:"Symbols and scope",occurrences:0,answered:0,correct:0)]
        model.consent=true;await generate(model,stats)
        let firstID=model.currentSessionID,firstDate=model.currentCreatedAt
        model.submit(index:0,choice:0);model.submit(index:1,choice:0)
        precondition(model.historySummary().answered == 2 && model.historySummary().correct == 1)
        precondition(model.historySummary().accuracy == "50%" && model.historySummary().topics.count == 2)
        await generate(model,stats);model.submit(index:0,choice:0)
        let secondID=model.currentSessionID
        precondition(model.historySummary().answered == 3 && model.historySummary().correct == 2)
        let withOld=model.historySummary(legacy:LegacyPracticeSummary(answered:2,correct:1,topics:["Boundary conditions"]))
        precondition(withOld.answered == 5 && withOld.correct == 3 && withOld.accuracy == "60%" && withOld.topics.count == 3)
        precondition(model.resumeSession(firstID))
        precondition(model.currentSessionID == firstID && model.currentCreatedAt == firstDate)
        precondition(model.historySummary().answered == 3 && model.historySessions.count == 2)
        precondition(model.currentSession?.savedAnswer(at:0) == 0 && model.currentSession?.savedAnswer(at:1) == 0)
        model.submit(index:2,choice:2)
        precondition(model.historySummary().answered == 4 && model.historySummary().correct == 3 && model.historySummary().accuracy == "75%")
        let restored=ReasoningModel(storageURL:url)
        precondition(restored.currentSessionID == firstID && restored.currentCreatedAt == firstDate)
        precondition(restored.historySummary().answered == 4 && restored.historySessions.count == 2)
        precondition(restored.currentSession?.savedAnswer(at:2) == 2)
        // An isolated write failure must roll back a resume and retain the failure message.
        try FileManager.default.removeItem(at:url)
        try FileManager.default.createDirectory(at:url,withIntermediateDirectories:false)
        precondition(!model.resumeSession(secondID))
        precondition(model.currentSessionID == firstID && model.historySummary().answered == 4)
        precondition(model.message.hasPrefix("Could not save"))
        model.clearLearning()
        precondition(model.message.hasPrefix("Could not save"),"A failed clear must not claim success")
        // Old records without timestamps, topics or complete answer arrays still decode.
        let oldURL=dir.appendingPathComponent("old.json")
        let quiz=Quiz(question:"Old question",choices:["A","B","C","D"],answer:0,explanation:"Old explanation")
        let data:[String:Any]=["observations":[],"exercises":try JSONSerialization.jsonObject(with:JSONEncoder().encode([quiz,quiz])),"answers":[0],"day":"2026-11-01","archive":[]]
        try JSONSerialization.data(withJSONObject:data).write(to:oldURL)
        let old=ReasoningModel(storageURL:oldURL)
        precondition(old.historySummary().answered == 1 && old.historySummary().correct == 1 && old.historySummary().topics.isEmpty)
        precondition(old.answers == [0,-1] && old.currentSession?.createdAt == nil)
        print("PASS history totals/accuracy/concepts, legacy totals, stable IDs/timestamps, resume without double counting, answer restoration, failed-save rollback and older JSON compatibility")
    }
    @MainActor static func generate(_ model:ReasoningModel,_ stats:[TopicStat]) async {
        model.generate(stats:stats,mode:.mixed)
        for _ in 0..<200 {
            if !model.busy { return }
            try? await Task.sleep(nanoseconds:10_000_000)
        }
        preconditionFailure("Mock generation timed out")
    }
}
