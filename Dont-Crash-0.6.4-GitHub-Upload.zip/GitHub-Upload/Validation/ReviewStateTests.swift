// Historical AI observation schemas remain covered by ReasoningTests.
// See PracticeRefreshTests.swift for history migration and unified workflow tests.
