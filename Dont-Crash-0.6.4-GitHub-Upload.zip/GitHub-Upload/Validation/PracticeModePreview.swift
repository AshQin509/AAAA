import Foundation
import SwiftUI
import AppKit

@main struct PracticeModePreview {
    @MainActor static func main() async throws {
        _=NSApplication.shared
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at:dir) }
        let suite="mode-preview-"+UUID().uuidString;let prefs=UserDefaults(suiteName:suite)!
        defer { prefs.removePersistentDomain(forName:suite) }
        let model=ReasoningModel(storageURL:dir.appendingPathComponent("history.json"),requester:{ _,_,_,stats,mode in
            (0..<mode.questionCount).map { i in PracticeItem(topic:stats[i % stats.count].topic,quiz:Quiz(question:"\(mode.rawValue): independent question \(i+1)",choices:["A","B","C","D"],answer:0,explanation:"Reason")) }
        })
        let app=AppModel(preview:true,reasoningModel:model,preferences:prefs)
        app.notesStats=[TopicStat(topic:"Types and conversions",occurrences:3,answered:0,correct:0),TopicStat(topic:"Symbols and scope",occurrences:2,answered:0,correct:0)]
        let output=URL(fileURLWithPath:CommandLine.arguments[1],isDirectory:true)
        try FileManager.default.createDirectory(at:output,withIntermediateDirectories:true)
        for kind in [PracticeMode.mixed,.topic] {
            if kind == .mixed { app.selectPracticeMode(0) } else { app.selectPracticeTopic("Types and conversions") }
            model.consent=true;model.generate(stats:app.practiceStats,mode:kind)
            for _ in 0..<100 { if !model.busy { break };try? await Task.sleep(nanoseconds:10_000_000) }
            precondition(model.exercises.count == kind.questionCount)
            let view=NSHostingView(rootView:CoachPanel(model:app,collapse:{},initialTab:2))
            view.frame=NSRect(x:0,y:0,width:620,height:720)
            let window=NSWindow(contentRect:view.frame,styleMask:[.borderless],backing:.buffered,defer:false)
            window.contentView=view;view.layoutSubtreeIfNeeded()
            if let bitmap=view.bitmapImageRepForCachingDisplay(in:view.bounds) {
                view.cacheDisplay(in:view.bounds,to:bitmap)
                try bitmap.representation(using:.png,properties:[:])?.write(to:output.appendingPathComponent(kind == .mixed ? "mixed-practice.png":"topic-practice.png"))
            }
            window.contentView=nil
        }
        print("Rendered separate Mixed/3 and Topic/1 practice views")
    }
}
