import Foundation
import SwiftUI

@main struct PracticeModeTests {
    @MainActor static func main() async throws {
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:dir) }
        var slow=false
        var requests:[(PracticeMode,[String])]=[]
        let model=ReasoningModel(storageURL:dir.appendingPathComponent("history.json"),requester:{ _,_,_,stats,mode in
            requests.append((mode,stats.map(\.topic)))
            if slow { try await Task.sleep(nanoseconds:150_000_000) }
            return (0..<mode.questionCount).map { i in PracticeItem(topic:stats[i % stats.count].topic,quiz:Quiz(question:"\(mode.rawValue) \(requests.count) \(i)",choices:["A","B","C","D"],answer:0,explanation:"Reason")) }
        })
        let suite="mode-test-"+UUID().uuidString;let prefs=UserDefaults(suiteName:suite)!
        defer { prefs.removePersistentDomain(forName:suite) }
        let app=AppModel(preview:true,reasoningModel:model,preferences:prefs)
        let notes=Array(IndependentPractice.topics.prefix(6))
        app.notesStats=notes.enumerated().map { TopicStat(topic:$0.element,occurrences:$0.offset+1,answered:0,correct:0) }
        app.selectPracticeMode(0);model.consent=true;await generate(app)
        let mixedID=model.currentSessionID
        precondition(model.exercises.count == 3 && requests.last?.0 == .mixed)
        precondition(requests.last?.1 == notes,"Mixed must receive every Notes concept")
        model.submit(index:0,choice:0)
        app.selectPracticeTopic("Boundary conditions")
        precondition(model.exercises.isEmpty,"Mixed questions must disappear on entering a new topic")
        await generate(app)
        let boundaryID=model.currentSessionID
        precondition(model.exercises.count == 1 && requests.last?.1 == ["Boundary conditions"])
        model.submit(index:0,choice:0)
        app.selectPracticeMode(0)
        precondition(model.currentSessionID == mixedID && model.exercises.count == 3 && model.answers[0] == 0)
        app.selectPracticeTopic("Types and conversions")
        precondition(model.exercises.isEmpty,"A different topic must not display the previous topic question")
        await generate(app)
        let typeID=model.currentSessionID
        precondition(model.exercises.count == 1 && requests.last?.1 == ["Types and conversions"])
        app.selectPracticeTopic("Boundary conditions")
        precondition(model.currentSessionID == boundaryID && model.exercises.count == 1 && model.answers == [0])
        precondition(model.historySessions.count == 3 && model.historySummary().answered == 2)
        app.selectPracticeTopic("Types and conversions")
        precondition(model.currentSessionID == typeID)
        slow=true;let count=model.historySessions.count
        model.generate(stats:app.practiceStats,mode:.topic)
        app.selectPracticeMode(0)
        try? await Task.sleep(nanoseconds:250_000_000)
        precondition(model.currentSessionID == mixedID && model.historySessions.count == count && !model.busy)
        let old=PracticeSession(day:"2026-11-01",exercises:model.exercises,answers:[-1,-1,-1],topics:Array(repeating:"Symbols and scope",count:3),mode:"Topic Practice")
        model.archive.append(old)
        app.selectPracticeTopic("Symbols and scope")
        precondition(model.exercises.isEmpty,"Old three-question Topic sets must not return as active single-question practice")
        precondition(model.historySessions.contains{$0.id == old.id} && !old.isResumable)
        precondition(!model.resumeSession(old.id))
        let restored=ReasoningModel(storageURL:dir.appendingPathComponent("history.json"))
        let restoredApp=AppModel(preview:true,reasoningModel:restored,preferences:prefs)
        restoredApp.notesStats=app.notesStats
        restoredApp.selectPracticeMode(0)
        precondition(restored.currentSessionID == mixedID && restored.exercises.count == 3)
        restoredApp.selectPracticeTopic("Boundary conditions")
        precondition(restored.currentSessionID == boundaryID && restored.answers == [0])
        print("PASS all Notes supplied to Mixed/3, single-topic/1, isolated sets and answers, restart restoration, cancellation, legacy-set preservation and no double counting")
    }
    @MainActor static func generate(_ app:AppModel) async {
        app.reasoning.generate(stats:app.practiceStats,mode:app.selectedPracticeMode)
        for _ in 0..<200 { if !app.reasoning.busy { return };try? await Task.sleep(nanoseconds:10_000_000) }
        preconditionFailure("Mock generation timed out")
    }
}
