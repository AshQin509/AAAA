import Foundation
import SwiftUI
import AppKit

@main struct ComicLayoutTests {
    @MainActor static func main() throws {
        _=NSApplication.shared
        let model=AppModel(preview:true)
        precondition(!model.showEmptyCompilerStatistics)
        let source=EditorCode(application:"Test editor",identity:"test-source",filename:"Main.java",text:"class Main {}")
        model.capturedSource=source;model.currentFile=source.filename
        precondition(!model.showEmptyCompilerStatistics,"A selected but unchecked file must not show the empty-statistics message")
        model.lastCleanCompilerFingerprint=Diagnostic.digest(source.identity+"|"+source.text)
        precondition(model.showEmptyCompilerStatistics)
        model.busy=true
        precondition(!model.showEmptyCompilerStatistics)
        model.busy=false
        model.capturedSource=EditorCode(application:"Test editor",identity:source.identity,filename:source.filename,text:"class Main { int n = ; }")
        precondition(!model.showEmptyCompilerStatistics,"Changed source invalidates the clean result")
        model.capturedSource=source;model.currentFile=""
        precondition(!model.showEmptyCompilerStatistics,"Disconnection must hide the message")
        model.capturedSource=nil;model.lastCleanCompilerFingerprint=nil
        print("PASS empty-statistics visibility: no source, unchecked, passed, checking, edited, disconnected")
        let output=URL(fileURLWithPath:CommandLine.arguments[1],isDirectory:true)
        try FileManager.default.createDirectory(at:output,withIntermediateDirectories:true)
        for tab in [0,1,2,3] {
            let view=NSHostingView(rootView:CoachPanel(model:model,collapse:{},initialTab:tab))
            view.frame=NSRect(x:0,y:0,width:620,height:720)
            let window=NSWindow(contentRect:view.frame,styleMask:[.borderless],backing:.buffered,defer:false)
            window.contentView=view;view.layoutSubtreeIfNeeded()
            if let bitmap=view.bitmapImageRepForCachingDisplay(in:view.bounds) {
                view.cacheDisplay(in:view.bounds,to:bitmap)
                try bitmap.representation(using:.png,properties:[:])?.write(to:output.appendingPathComponent("workflow-tab-\(tab).png"))
            }
            window.contentView=nil
        }
        model.notesStats=[TopicStat(topic:"Types and conversions",occurrences:3,answered:2,correct:1),TopicStat(topic:"Symbols and scope",occurrences:1,answered:0,correct:0)]
        model.practiceMode=1
        for tab in [1,2] {
            let view=NSHostingView(rootView:CoachPanel(model:model,collapse:{},initialTab:tab))
            view.frame=NSRect(x:0,y:0,width:620,height:720)
            let window=NSWindow(contentRect:view.frame,styleMask:[.borderless],backing:.buffered,defer:false)
            window.contentView=view;view.layoutSubtreeIfNeeded()
            if let bitmap=view.bitmapImageRepForCachingDisplay(in:view.bounds) {
                view.cacheDisplay(in:view.bounds,to:bitmap)
                try bitmap.representation(using:.png,properties:[:])?.write(to:output.appendingPathComponent("workflow-populated-\(tab).png"))
            }
            window.contentView=nil
        }
        print("Rendered Check, Notes, Practice and Settings")
    }
}
