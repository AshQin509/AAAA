import Foundation
import SwiftUI

@main struct PracticeRefreshTests {
    @MainActor static func main() async throws {
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:dir) }
        let url=dir.appendingPathComponent("reasoning.json")
        let analysis=try JSONDecoder().decode(ConceptAnalysis.self,from:Data(#"{"language":"java","concept":"Boundary conditions","possibleHabit":"Old AI inference","evidence":"PRIVATE_SOURCE_CODE","confidence":"medium","suggestedPractice":"Old suggestion"}"#.utf8))
        let oldQuiz=Quiz(question:"Legacy question",choices:["A","B","C","D"],answer:0,explanation:"Legacy explanation")
        let legacy:[String:Any]=["observations":try JSONSerialization.jsonObject(with:JSONEncoder().encode([ReasoningObservation(analysis:analysis)])),"exercises":try JSONSerialization.jsonObject(with:JSONEncoder().encode([oldQuiz])),"answers":[0],"day":"2026-11-01","archive":[]]
        try JSONSerialization.data(withJSONObject:legacy).write(to:url)
        var requests=0,invalid=false,slow=false
        var used:[AIProvider]=[]
        var usedWorkspaces:[String]=[]
        let model=ReasoningModel(storageURL:url,requester:{ provider,_,workspace,stats,mode in
            requests += 1;used.append(provider);usedWorkspaces.append(workspace.host)
            if slow { try await Task.sleep(nanoseconds:200_000_000) }
            let input=try IndependentPractice.payload(stats)
            precondition(!input.contains("PRIVATE_SOURCE_CODE"))
            return (0..<(invalid ? 2:mode.questionCount)).map { i in
                PracticeItem(topic:stats[i % stats.count].topic,quiz:Quiz(question:"Request \(requests), question \(i)",choices:["A","B","C","D"],answer:i,explanation:"Independent explanation"))
            }
        })
        precondition(model.observations.count == 1 && model.exercises.count == 1 && model.answers == [0])
        let suite="workflow-test-"+UUID().uuidString
        let preferences=UserDefaults(suiteName:suite)!
        defer { preferences.removePersistentDomain(forName:suite) }
        let app=AppModel(preview:true,reasoningModel:model,preferences:preferences)
        precondition(app.practiceStats.isEmpty,"Old AI observations must not become Mixed Practice topics")
        app.selectPracticeTopic("Types and conversions")
        precondition(app.practiceStats.count == 1 && app.practiceStats[0].answered == 0)
        model.consent=true;await generate(model,app.practiceStats)
        precondition(requests == 1 && model.exercises.count == 1 && model.archive.count == 1)
        precondition(model.archive[0].answers == [0],"Legacy answers must be archived")
        model.submit(index:0,choice:0);model.submit(index:0,choice:1)
        precondition(model.answers[0] == 0 && model.topicPerformance("Types and conversions").answered == 1)
        let firstDay=model.day,oldID=model.practiceSetID
        await generate(model,app.practiceStats)
        precondition(requests == 2 && model.day == firstDay && model.practiceSetID != oldID)
        precondition(model.answers == [-1] && model.archive.count == 2)
        model.submit(index:0,choice:1)
        let previous=model.exercises
        invalid=true;await generate(model,app.practiceStats)
        precondition(model.exercises == previous && model.answers[0] == 1 && model.archive.count == 2)
        invalid=false
        for provider in [AIProvider.openai,.deepseek,.databricks] {
            app.provider=provider;app.model="test-"+provider.rawValue
            precondition(model.provider == provider && model.model == app.model && !model.consent)
            model.consent=true;await generate(model,app.practiceStats)
            precondition(used.last == provider)
        }
        app.provider = .openai
        precondition(app.model == "test-OpenAI","Each provider's model choice must persist")
        let restored=ReasoningModel(storageURL:url)
        precondition(restored.observations.count == 1 && restored.archive.first?.answers == [0])
        precondition(restored.exercises.count == 1 && restored.exerciseTopics.count == 1)
        model.consent=true;slow=true;let count=model.archive.count;model.generate(stats:app.practiceStats,mode:.topic)
        app.provider = .databricks
        try? await Task.sleep(nanoseconds:300_000_000)
        precondition(!model.busy && model.archive.count == count,"Changing provider cancels and discards old responses")
        slow=false;app.provider = .databricks
        let legacyWorkspace=app.databricksWorkspace
        model.consent=true
        app.workspaceInput="https://DBC-NEW.cloud.databricks.com/?o=123"
        precondition(app.workspaceChangesPending && app.databricksWorkspace == legacyWorkspace)
        app.saveKey("dummy-never-saved")
        precondition(app.issue?.contains("Apply workspace") == true)
        app.applyWorkspace()
        precondition(!app.workspaceChangesPending && app.databricksWorkspace.host == "dbc-new.cloud.databricks.com")
        precondition(model.workspace == app.databricksWorkspace && !model.consent)
        model.consent=true;await generate(model,app.practiceStats)
        precondition(usedWorkspaces.last == "dbc-new.cloud.databricks.com")
        slow=true;model.consent=true;let oldCount=model.archive.count
        model.generate(stats:app.practiceStats,mode:.topic)
        app.workspaceInput="https://adb-123.azuredatabricks.net";app.applyWorkspace()
        try? await Task.sleep(nanoseconds:300_000_000)
        precondition(!model.consent && !model.busy && model.archive.count == oldCount)
        let applied=app.databricksWorkspace
        app.workspaceInput="http://invalid.example";app.applyWorkspace()
        precondition(app.databricksWorkspace == applied && app.issue != nil)
        let restoredApp=AppModel(preview:true,preferences:preferences)
        precondition(restoredApp.databricksWorkspace == applied)
        precondition(AIProvider.databricks.credentialService(workspace:applied) != AIProvider.databricks.credentialService(workspace:legacyWorkspace))
        print("PASS workspace apply/persistence, pending-edit credential guard, custom generation routing and cancellation")
        print("PASS legacy history, no-source Topic Practice, old AI observation exclusion, refresh/answers, failure preservation, three-provider routing, saved models and cancellation")
    }
    @MainActor static func generate(_ model:ReasoningModel,_ stats:[TopicStat]) async {
        model.generate(stats:stats,mode:.topic)
        for _ in 0..<300 {
            if !model.busy { return }
            try? await Task.sleep(nanoseconds:10_000_000)
        }
        preconditionFailure("Mock generation timed out")
    }
}
