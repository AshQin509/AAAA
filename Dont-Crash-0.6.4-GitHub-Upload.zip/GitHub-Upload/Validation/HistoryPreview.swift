import Foundation
import SwiftUI
import AppKit

@main struct HistoryPreview {
    @MainActor static func main() async throws {
        _=NSApplication.shared
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at:dir) }
        let output=URL(fileURLWithPath:CommandLine.arguments[1],isDirectory:true)
        try FileManager.default.createDirectory(at:output,withIntermediateDirectories:true)
        let model=ReasoningModel(storageURL:dir.appendingPathComponent("history.json"),requester:{ _,_,_,stats,mode in
            (0..<3).map { i in
                PracticeItem(topic:stats[i % stats.count].topic,quiz:Quiz(question:"Which expression correctly converts an integer value to a double?",choices:["double result = value;","int result = (double) value;","double result = \"value\";","double result = null;"],answer:0,explanation:"Java allows an int to widen to double. The other options use incompatible types."))
            }
        })
        let stats=[TopicStat(topic:"Types and conversions",occurrences:3,answered:0,correct:0),TopicStat(topic:"Symbols and scope",occurrences:1,answered:0,correct:0)]
        model.consent=true;model.generate(stats:stats,mode:.mixed)
        for _ in 0..<100 { if !model.busy { break };try? await Task.sleep(nanoseconds:10_000_000) }
        model.submit(index:0,choice:0);model.submit(index:1,choice:1)
        model.generate(stats:stats,mode:.mixed)
        for _ in 0..<100 { if !model.busy { break };try? await Task.sleep(nanoseconds:10_000_000) }
        model.submit(index:0,choice:0)
        let suite="history-preview-"+UUID().uuidString
        let prefs=UserDefaults(suiteName:suite)!
        defer { prefs.removePersistentDomain(forName:suite) }
        let app=AppModel(preview:true,reasoningModel:model,preferences:prefs)
        app.notesStats=stats
        try render(PracticeHistoryView(app:app,model:model,onBack:{},onResume:{_ in}),name:"practice-history",output:output)
        let review=model.archive[0]
        try render(PracticeQuestionReview(quiz:review.exercises[1],number:2,topic:review.topics?[1],answer:review.savedAnswer(at:1)),name:"history-question-review",output:output)
        let panel=NSHostingView(rootView:CoachPanel(model:app,collapse:{},initialTab:2))
        panel.frame=NSRect(x:0,y:0,width:620,height:720)
        try snapshot(panel,path:output.appendingPathComponent("practice-history-entry.png"))
        print("Rendered Practice History overview, saved answer review and Practice entry")
    }
    @MainActor static func render<V:View>(_ content:V,name:String,output:URL) throws {
        let view=NSHostingView(rootView:ScrollView { content.padding(20) }.frame(width:620,height:720).background(Color.white).preferredColorScheme(.light))
        view.frame=NSRect(x:0,y:0,width:620,height:720)
        try snapshot(view,path:output.appendingPathComponent(name+".png"))
    }
    @MainActor static func snapshot(_ view:NSView,path:URL) throws {
        let window=NSWindow(contentRect:view.frame,styleMask:[.borderless],backing:.buffered,defer:false)
        window.contentView=view;view.layoutSubtreeIfNeeded()
        if let bitmap=view.bitmapImageRepForCachingDisplay(in:view.bounds) {
            view.cacheDisplay(in:view.bounds,to:bitmap)
            try bitmap.representation(using:.png,properties:[:])?.write(to:path)
        }
        window.contentView=nil
    }
}
