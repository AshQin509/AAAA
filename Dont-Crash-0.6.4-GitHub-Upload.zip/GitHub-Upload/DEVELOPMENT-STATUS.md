# Current development status

The active implementation is the unified Check / Notes / Practice / Settings workflow described in README.md. Direct AI code analysis, AI diagnostic explanations and the earlier single-question generator have been removed. Old AI observation schemas are retained only to decode archived records.

All live practice generation uses DatabricksClient.generatePractice with the selected provider and model. Three-provider credential IDs are unchanged. No live provider request or secret inspection was performed for this refactor.

Previous prototype reports remain historical references, not current feature specifications. See WORKFLOW-REFACTOR.md for current checks and limitations.

Practice History is now inside Practice, above the Mixed / Topic selector. It includes cumulative submitted-answer metrics, current and archived sets, saved answer review and unfinished-set continuation.

Mixed Practice requests three questions from all Notes concepts. Topic Practice requests one question on a selected concept. Their current sets and answers are restored separately by mode and topic; older incompatible sets remain reviewable in History.
