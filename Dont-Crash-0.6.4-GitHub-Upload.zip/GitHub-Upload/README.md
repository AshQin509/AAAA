# Don't Crash — learning workflow

A native macOS Java learning assistant: local compiler checks → concept notes → independent AI practice.

- **Check:** choose a saved `.java` file or use Accessibility editor capture. Checks run with local `javac`; the app does not execute student programs or send source to AI.
- **Notes:** groups locally recorded compiler diagnostics by fixed concept categories across source files. Counts describe diagnostic events, not ability or mastery.
- **Practice:** Mixed Practice uses all recorded Notes concepts and their counts to request exactly three questions. Topic Practice requests exactly one question on the selected concept, including for new users without connected source. Both use the same generator and allow refreshes. Each mode and selected topic restores its own latest saved set. Only whitelisted concept names and aggregate diagnostic/answer counts are sent.
- **Practice History:** use the button above Mixed / Topic Practice to review lifetime submitted-answer totals, accuracy, practiced concepts and saved question sets. Review your saved selections and explanations, or continue unfinished sets. Unanswered questions do not count against accuracy. The separate Progress page has been removed; archived AI observations remain on disk only for compatibility.
- **Settings:** one selected provider/model for all AI practice and connection tests. Databricks, OpenAI and DeepSeek retain separate Keychain credentials. Switching service/model cancels pending work and resets consent.

## Run

Open `CodeCoach.xcodeproj`, select CodeCoach / My Mac, and run. Or use `scripts/build-app.sh`; the app is written to `build/CodeCoach.app`. macOS 13+ and a compatible Swift/Xcode toolchain are required. Install a JDK for local Java checks; independent Topic Practice does not require one.

In Settings, select the service, review the model ID, and save your API credential. For Databricks, paste the workspace URL and click Apply workspace first. Workspace changes are saved locally; each workspace keeps a separate Keychain credential, and the original workspace retains its existing credential identity. Existing credentials use the same Keychain service IDs as before. Enable AI requests and test the selected service. Requests may incur provider charges. No keys belong in source or Git.

AI-generated questions and answers may be inaccurate. Compiler success does not establish runtime correctness. Single-file checks do not resolve full Maven/Gradle dependencies. The app does not guarantee compliance with every course policy.

## History and Git

Existing `learning.sqlite` and `reasoning.json` remain in the same Application Support location. Earlier single-question answers remain in SQLite; earlier question sets and AI observations remain readable. New sets and answers share one JSON history, with explicit topic associations. Unknown-topic legacy exercises are preserved without guessing a topic.

The local repository has `archive/pre-simplification` for the original app and `refactor/learning-workflow` for this implementation. No GitHub push has been performed.

See `WORKFLOW-REFACTOR.md` for validation and implementation details. Earlier UX and validation reports describe historical versions.
